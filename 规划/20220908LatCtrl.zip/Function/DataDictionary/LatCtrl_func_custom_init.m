% Custom local definitions
LatCtrl_const;

% Custom files needed by composition
needed_by_composition{1} = 'commonLatCtrl\LatCtrlCalcCubicSplineSlopes.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlCalcCurvatureDesired.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlCalcPathEvaluationMetrics.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlDoubleLinLimit.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlDoubleTanHypLimit.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlEvaluateCubicSpline.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlInvBicycleModelStaticGain.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlLKAinitializeLanePolynom.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlLKAupdateLanePolynom.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlLeadFilter.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlLimitStandStillGain.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlLimitVelocity.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlTanHypLinLimit.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlTheta.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlBiquadFilter.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrlRunningAverage.m';
needed_by_composition{end+1} = 'commonLatCtrl\LatCtrl_Fcns_lib.mdl';
needed_by_composition{end+1} = 'SelectConfigurationInLatCtrl.m';

% Custom local Simulink.Enum definitions

