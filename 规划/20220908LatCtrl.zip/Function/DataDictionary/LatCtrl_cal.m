% k_LQR_T_IPartResetHoldHigh%
k_LQR_T_IPartResetHoldHigh= AUTOSAR.Parameter;
k_LQR_T_IPartResetHoldHigh.Value = single(3);
k_LQR_T_IPartResetHoldHigh.RTWInfo.StorageClass = 'ExportedGlobal';
k_LQR_T_IPartResetHoldHigh.RTWInfo.Alias = '';
k_LQR_T_IPartResetHoldHigh.RTWInfo.CustomStorageClass = 'InternalCalPrm';
k_LQR_T_IPartResetHoldHigh.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
k_LQR_T_IPartResetHoldHigh.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
k_LQR_T_IPartResetHoldHigh.Description = 'LQR Time for for LQR Ctrol Steady State Error interpolation Reset Hold High';
k_LQR_T_IPartResetHoldHigh.DataType = 'single';
k_LQR_T_IPartResetHoldHigh.Min = 0;
k_LQR_T_IPartResetHoldHigh.Max = 100;
k_LQR_T_IPartResetHoldHigh.DocUnits = ' ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% LatCtrl_LQRCtrl_Active%
LatCtrl_LQRCtrl_Active= AUTOSAR.Parameter;
LatCtrl_LQRCtrl_Active.Value = boolean(0);
LatCtrl_LQRCtrl_Active.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRCtrl_Active.RTWInfo.Alias = '';
LatCtrl_LQRCtrl_Active.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRCtrl_Active.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRCtrl_Active.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRCtrl_Active.Description = 'Active the LQR Control Angle to Output ';
LatCtrl_LQRCtrl_Active.DataType = 'boolean';
LatCtrl_LQRCtrl_Active.Min = 0;
LatCtrl_LQRCtrl_Active.Max = 8;
LatCtrl_LQRCtrl_Active.DocUnits = ' ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_LQRSteadyErrorICtrlTest%
LatCtrl_LQRSteadyErrorICtrlSlect= AUTOSAR.Parameter;
LatCtrl_LQRSteadyErrorICtrlSlect.Value = uint8(5);
LatCtrl_LQRSteadyErrorICtrlSlect.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRSteadyErrorICtrlSlect.RTWInfo.Alias = '';
LatCtrl_LQRSteadyErrorICtrlSlect.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRSteadyErrorICtrlSlect.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRSteadyErrorICtrlSlect.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRSteadyErrorICtrlSlect.Description = 'Active the LQR SteadyError I Ctrl For Test  Slect';
LatCtrl_LQRSteadyErrorICtrlSlect.DataType = 'uint8';
LatCtrl_LQRSteadyErrorICtrlSlect.Min = 0;
LatCtrl_LQRSteadyErrorICtrlSlect.Max = 8;
LatCtrl_LQRSteadyErrorICtrlSlect.DocUnits = ' ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_LQRSteadyStateErrorIMetrics%
LatCtrl_LQRSteadyStateErrorIMetrics= AUTOSAR.Parameter;
LatCtrl_LQRSteadyStateErrorIMetrics.Value = single([0.0050, 0.00450, 0.0045, 0.0040, 0.0060, 0.0040, 0.0025]);
LatCtrl_LQRSteadyStateErrorIMetrics.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRSteadyStateErrorIMetrics.RTWInfo.Alias = '';
LatCtrl_LQRSteadyStateErrorIMetrics.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRSteadyStateErrorIMetrics.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRSteadyStateErrorIMetrics.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRSteadyStateErrorIMetrics.Description = 'I for LQR Ctrol Steady State Error  ';
LatCtrl_LQRSteadyStateErrorIMetrics.DataType = 'single';
LatCtrl_LQRSteadyStateErrorIMetrics.Min = -100;
LatCtrl_LQRSteadyStateErrorIMetrics.Max = 100;
LatCtrl_LQRSteadyStateErrorIMetrics.DocUnits = ' ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LatCtrl_LQRSpeedValue%
LatCtrl_LQRSpeedValue= AUTOSAR.Parameter;
LatCtrl_LQRSpeedValue.Value = single([0,10,20,30,40,50,60]/3.6);
LatCtrl_LQRSpeedValue.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRSpeedValue.RTWInfo.Alias = '';
LatCtrl_LQRSpeedValue.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRSpeedValue.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRSpeedValue.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRSpeedValue.Description = 'LQR speed for for LQR Ctrol Steady State Error interpolation';
LatCtrl_LQRSpeedValue.DataType = 'single';
LatCtrl_LQRSpeedValue.Min = 0;
LatCtrl_LQRSpeedValue.Max = 150/3.6;
LatCtrl_LQRSpeedValue.DocUnits = 'm/s ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_LQRSteadyErrorLimitFector%
LatCtrl_LQRSteadyErrorLimitFector= AUTOSAR.Parameter;
LatCtrl_LQRSteadyErrorLimitFector.Value = single([10.1, 10.1, 10.1, 10.1, 10.1, 10.1, 10.1]);
LatCtrl_LQRSteadyErrorLimitFector.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRSteadyErrorLimitFector.RTWInfo.Alias = '';
LatCtrl_LQRSteadyErrorLimitFector.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRSteadyErrorLimitFector.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRSteadyErrorLimitFector.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRSteadyErrorLimitFector.Description = 'Time For Preview Fector for TiStep ';
LatCtrl_LQRSteadyErrorLimitFector.DataType = 'single';
LatCtrl_LQRSteadyErrorLimitFector.Min = 0;
LatCtrl_LQRSteadyErrorLimitFector.Max = 100;
LatCtrl_LQRSteadyErrorLimitFector.DocUnits = ' ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% LatCtrl_LQRYawSign%
LatCtrl_LQRYawRateSign = AUTOSAR.Parameter;
LatCtrl_LQRYawRateSign.Value = 1;
LatCtrl_LQRYawRateSign.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRYawRateSign.RTWInfo.Alias = '';
LatCtrl_LQRYawRateSign.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRYawRateSign.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRYawRateSign.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRYawRateSign.Description = 'Sign of the Yawrate for LQR Control ';
LatCtrl_LQRYawRateSign.DataType = 'single';
LatCtrl_LQRYawRateSign.Min = -2;
LatCtrl_LQRYawRateSign.Max = 2;
LatCtrl_LQRYawRateSign.DocUnits = ' ';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LatCtrl_LQRMetricsK %
LatCtrl_LQRMetricsK= AUTOSAR.Parameter;
LatCtrl_LQRMetricsK.Value = [0.015	0.001	0.262	0.0006;
    0.014	0.001	0.289	0.0120;
    0.013	0.001	0.340	0.0210;
    0.012	0.001	0.3670	0.0290; 
    0.011	0.002	0.3760	0.0360;
    0.009	0.002	0.3450	0.0380];
LatCtrl_LQRMetricsK.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_LQRMetricsK.RTWInfo.Alias = '';
LatCtrl_LQRMetricsK.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_LQRMetricsK.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_LQRMetricsK.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_LQRMetricsK.Description = 'KMetrics for LQR control ';
LatCtrl_LQRMetricsK.DataType = 'single';
LatCtrl_LQRMetricsK.Min = -100;
LatCtrl_LQRMetricsK.Max = 100;
LatCtrl_LQRMetricsK.DocUnits = '';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LatCtrl_PinAgReqOffsForLeftTurn %
LatCtrl_PinAgReqOffsForLeftTurn = AUTOSAR.Parameter;
LatCtrl_PinAgReqOffsForLeftTurn.Value = 0.02;
LatCtrl_PinAgReqOffsForLeftTurn.RTWInfo.StorageClass = 'ExportedGlobal';
LatCtrl_PinAgReqOffsForLeftTurn.RTWInfo.Alias = '';
LatCtrl_PinAgReqOffsForLeftTurn.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_PinAgReqOffsForLeftTurn.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_PinAgReqOffsForLeftTurn.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_PinAgReqOffsForLeftTurn.Description = '';
LatCtrl_PinAgReqOffsForLeftTurn.DataType = 'single';
LatCtrl_PinAgReqOffsForLeftTurn.Min = 0;
LatCtrl_PinAgReqOffsForLeftTurn.Max = 1;
LatCtrl_PinAgReqOffsForLeftTurn.DocUnits = 'rad';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LatCtrl_PinAgCtrllerKpInShit %
LatCtrl_PinAgCtrllerKpInShit = AUTOSAR.Parameter;
LatCtrl_PinAgCtrllerKpInShit.Value = 16;
LatCtrl_PinAgCtrllerKpInShit.RTWInfo.StorageClass = 'Custom';
LatCtrl_PinAgCtrllerKpInShit.RTWInfo.Alias = '';
LatCtrl_PinAgCtrllerKpInShit.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_PinAgCtrllerKpInShit.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_PinAgCtrllerKpInShit.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_PinAgCtrllerKpInShit.Description = '';
LatCtrl_PinAgCtrllerKpInShit.DataType = 'single';
LatCtrl_PinAgCtrllerKpInShit.Min = 0;
LatCtrl_PinAgCtrllerKpInShit.Max = 50;
LatCtrl_PinAgCtrllerKpInShit.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_PinAgKpLimitTiLimit %
LatCtrl_PinAgKpLimitTiLimit = AUTOSAR.Parameter;
LatCtrl_PinAgKpLimitTiLimit.Value = 1.0;
LatCtrl_PinAgKpLimitTiLimit.RTWInfo.StorageClass = 'Custom';
LatCtrl_PinAgKpLimitTiLimit.RTWInfo.Alias = '';
LatCtrl_PinAgKpLimitTiLimit.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_PinAgKpLimitTiLimit.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_PinAgKpLimitTiLimit.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_PinAgKpLimitTiLimit.Description = '';
LatCtrl_PinAgKpLimitTiLimit.DataType = 'single';
LatCtrl_PinAgKpLimitTiLimit.Min = 0;
LatCtrl_PinAgKpLimitTiLimit.Max = 20;
LatCtrl_PinAgKpLimitTiLimit.DocUnits = 's';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_PinAgLimitCurvTiLimit %
LatCtrl_PinAgLimitCurvTiLimit = AUTOSAR.Parameter;
LatCtrl_PinAgLimitCurvTiLimit.Value = 3;
LatCtrl_PinAgLimitCurvTiLimit.RTWInfo.StorageClass = 'Custom';
LatCtrl_PinAgLimitCurvTiLimit.RTWInfo.Alias = '';
LatCtrl_PinAgLimitCurvTiLimit.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_PinAgLimitCurvTiLimit.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_PinAgLimitCurvTiLimit.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_PinAgLimitCurvTiLimit.Description = '';
LatCtrl_PinAgLimitCurvTiLimit.DataType = 'single';
LatCtrl_PinAgLimitCurvTiLimit.Min = 0;
LatCtrl_PinAgLimitCurvTiLimit.Max = 20;
LatCtrl_PinAgLimitCurvTiLimit.DocUnits = 's';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LatCtrl_PinAgLimitCurvThod %
LatCtrl_PinAgLimitCurvThod = AUTOSAR.Parameter;
LatCtrl_PinAgLimitCurvThod.Value = 1/500;
LatCtrl_PinAgLimitCurvThod.RTWInfo.StorageClass = 'Custom';
LatCtrl_PinAgLimitCurvThod.RTWInfo.Alias = '';
LatCtrl_PinAgLimitCurvThod.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_PinAgLimitCurvThod.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_PinAgLimitCurvThod.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_PinAgLimitCurvThod.Description = '';
LatCtrl_PinAgLimitCurvThod.DataType = 'single';
LatCtrl_PinAgLimitCurvThod.Min = 0;
LatCtrl_PinAgLimitCurvThod.Max = 1;
LatCtrl_PinAgLimitCurvThod.DocUnits = 'm^-1';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LatCtrl_CurvDesiredBP %
LatCtrl_CurvDesiredBP = AUTOSAR.Parameter;
LatCtrl_CurvDesiredBP.Value = [0 1/1800 1/1200 1/800 1/500 1/250 1/100 1/50];
LatCtrl_CurvDesiredBP.RTWInfo.StorageClass = 'Custom';
LatCtrl_CurvDesiredBP.RTWInfo.Alias = '';
LatCtrl_CurvDesiredBP.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_CurvDesiredBP.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_CurvDesiredBP.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_CurvDesiredBP.Description = '';
LatCtrl_CurvDesiredBP.DataType = 'single';
LatCtrl_CurvDesiredBP.Min = 0;
LatCtrl_CurvDesiredBP.Max = 1;
LatCtrl_CurvDesiredBP.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_FFGainInTurn %
LatCtrl_FFGainInTurn = AUTOSAR.Parameter;
% LatCtrl_FFGainInTurn.Value = [1.0 1.0 1.0 1.05 1.10 1.15 1.2 1.2];  % [0 1/1800 1/1200 1/800 1/500 1/250 1/100 1/50]
LatCtrl_FFGainInTurn.Value = [1.0 1.0 1.0 1.0 1.0 1.0 1.0 1.0];
LatCtrl_FFGainInTurn.RTWInfo.StorageClass = 'Custom';
LatCtrl_FFGainInTurn.RTWInfo.Alias = '';
LatCtrl_FFGainInTurn.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_FFGainInTurn.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_FFGainInTurn.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_FFGainInTurn.Description = '';
LatCtrl_FFGainInTurn.DataType = 'single';
LatCtrl_FFGainInTurn.Min = 1.0;
LatCtrl_FFGainInTurn.Max = 2.0;
LatCtrl_FFGainInTurn.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LatCtrl_PinAgCtrlKp %
LatCtrl_PinAgCtrlKp = AUTOSAR.Parameter;
LatCtrl_PinAgCtrlKp.Value = [10 10 9 8 5 3 2 2];  % [0 1/1800 1/1200 1/800 1/500 1/250 1/100 1/50]
LatCtrl_PinAgCtrlKp.RTWInfo.StorageClass = 'Custom';
LatCtrl_PinAgCtrlKp.RTWInfo.Alias = '';
LatCtrl_PinAgCtrlKp.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LatCtrl_PinAgCtrlKp.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LatCtrl_PinAgCtrlKp.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LatCtrl_PinAgCtrlKp.Description = '';
LatCtrl_PinAgCtrlKp.DataType = 'single';
LatCtrl_PinAgCtrlKp.Min = 1;
LatCtrl_PinAgCtrlKp.Max = 20;
LatCtrl_PinAgCtrlKp.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HdWayNomInLatCtrl %
HdWayNomInLatCtrl = AUTOSAR.Parameter;
% HdWayNomInLatCtrl.Value = [1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1 ; 1.2 1 1 1];
HdWayNomInLatCtrl.Value = [1.2 1 1 1];
HdWayNomInLatCtrl.RTWInfo.StorageClass = 'Custom';
HdWayNomInLatCtrl.RTWInfo.Alias = '';
HdWayNomInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
HdWayNomInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
HdWayNomInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
HdWayNomInLatCtrl.Description = '';
HdWayNomInLatCtrl.DataType = 'single';
HdWayNomInLatCtrl.Min = -20;
HdWayNomInLatCtrl.Max = 20;
HdWayNomInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_HdWayNomInLatCtrl %
LCA_HdWayNomInLatCtrl = AUTOSAR.Parameter;
LCA_HdWayNomInLatCtrl.Value = [1.6 1 1 1];
LCA_HdWayNomInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_HdWayNomInLatCtrl.RTWInfo.Alias = '';
LCA_HdWayNomInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_HdWayNomInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_HdWayNomInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_HdWayNomInLatCtrl.Description = '';
LCA_HdWayNomInLatCtrl.DataType = 'single';
LCA_HdWayNomInLatCtrl.Min = -20;
LCA_HdWayNomInLatCtrl.Max = 20;
LCA_HdWayNomInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HdWayMinInLatCtrl %
HdWayMinInLatCtrl = AUTOSAR.Parameter;
HdWayMinInLatCtrl.Value = [0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4 0.4];
HdWayMinInLatCtrl.RTWInfo.StorageClass = 'Custom';
HdWayMinInLatCtrl.RTWInfo.Alias = '';
HdWayMinInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
HdWayMinInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
HdWayMinInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
HdWayMinInLatCtrl.Description = '';
HdWayMinInLatCtrl.DataType = 'single';
HdWayMinInLatCtrl.Min = -4;
HdWayMinInLatCtrl.Max = 4;
HdWayMinInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HdWayLongInLatCtrl %
HdWayLongInLatCtrl = AUTOSAR.Parameter;
HdWayLongInLatCtrl.Value = [1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2];
HdWayLongInLatCtrl.RTWInfo.StorageClass = 'Custom';
HdWayLongInLatCtrl.RTWInfo.Alias = '';
HdWayLongInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
HdWayLongInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
HdWayLongInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
HdWayLongInLatCtrl.Description = '';
HdWayLongInLatCtrl.DataType = 'single';
HdWayLongInLatCtrl.Min = -12;
HdWayLongInLatCtrl.Max = 12;
HdWayLongInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HdWayLongerInLatCtrl %
HdWayLongerInLatCtrl = AUTOSAR.Parameter;
HdWayLongerInLatCtrl.Value = [1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6 1.6];
HdWayLongerInLatCtrl.RTWInfo.StorageClass = 'Custom';
HdWayLongerInLatCtrl.RTWInfo.Alias = '';
HdWayLongerInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
HdWayLongerInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
HdWayLongerInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
HdWayLongerInLatCtrl.Description = '';
HdWayLongerInLatCtrl.DataType = 'single';
HdWayLongerInLatCtrl.Min = -16;
HdWayLongerInLatCtrl.Max = 16;
HdWayLongerInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowrSpdLimInLatCtrl %
LowrSpdLimInLatCtrl = AUTOSAR.Parameter;
LowrSpdLimInLatCtrl.Value = [6 6 6 6 6 6 6 6 6 6 6 6 6];
LowrSpdLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowrSpdLimInLatCtrl.RTWInfo.Alias = '';
LowrSpdLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowrSpdLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowrSpdLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowrSpdLimInLatCtrl.Description = '';
LowrSpdLimInLatCtrl.DataType = 'single';
LowrSpdLimInLatCtrl.Min = -60;
LowrSpdLimInLatCtrl.Max = 60;
LowrSpdLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowrSpdLimSmthFacInLatCtrl %
LowrSpdLimSmthFacInLatCtrl = AUTOSAR.Parameter;
LowrSpdLimSmthFacInLatCtrl.Value = [.1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1];
LowrSpdLimSmthFacInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowrSpdLimSmthFacInLatCtrl.RTWInfo.Alias = '';
LowrSpdLimSmthFacInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowrSpdLimSmthFacInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowrSpdLimSmthFacInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowrSpdLimSmthFacInLatCtrl.Description = '';
LowrSpdLimSmthFacInLatCtrl.DataType = 'single';
LowrSpdLimSmthFacInLatCtrl.Min = -1;
LowrSpdLimSmthFacInLatCtrl.Max = 1;
LowrSpdLimSmthFacInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EvnLowrSpdLimInLatCtrl %
EvnLowrSpdLimInLatCtrl = AUTOSAR.Parameter;
EvnLowrSpdLimInLatCtrl.Value = [5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6 5/3.6];
EvnLowrSpdLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
EvnLowrSpdLimInLatCtrl.RTWInfo.Alias = '';
EvnLowrSpdLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
EvnLowrSpdLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
EvnLowrSpdLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
EvnLowrSpdLimInLatCtrl.Description = '';
EvnLowrSpdLimInLatCtrl.DataType = 'single';
EvnLowrSpdLimInLatCtrl.Min = -13.8889;
EvnLowrSpdLimInLatCtrl.Max = 13.8889;
EvnLowrSpdLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VForLinTunInLatCtrl %
VForLinTunInLatCtrl = AUTOSAR.Parameter;
% VForLinTunInLatCtrl.Value = [5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150 ; 5 10 25 50 100 150]/3.6;
VForLinTunInLatCtrl.Value = [5 10 25 50 75 100 125 150]/3.6;
VForLinTunInLatCtrl.RTWInfo.StorageClass = 'Custom';
VForLinTunInLatCtrl.RTWInfo.Alias = '';
VForLinTunInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VForLinTunInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VForLinTunInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VForLinTunInLatCtrl.Description = '';
VForLinTunInLatCtrl.DataType = 'single';
VForLinTunInLatCtrl.Min = -416.6667;
VForLinTunInLatCtrl.Max = 416.6667;
VForLinTunInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LocalOffsCtrlrPropGainInLatCtrl %
LocalOffsCtrlrPropGainInLatCtrl = AUTOSAR.Parameter;
% LocalOffsCtrlrPropGainInLatCtrl.Value = [.25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7];
LocalOffsCtrlrPropGainInLatCtrl.Value = [.25 .25 .6 .7 .7 .7 .7 .7];  % [5 10 25 50 75 100 125 150]km/h
LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.Alias = '';
LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LocalOffsCtrlrPropGainInLatCtrl.Description = '';
LocalOffsCtrlrPropGainInLatCtrl.DataType = 'single';
LocalOffsCtrlrPropGainInLatCtrl.Min = -7;
LocalOffsCtrlrPropGainInLatCtrl.Max = 7;
LocalOffsCtrlrPropGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_LocalOffsCtrlrPropGainInLatCtrl %
LCA_LocalOffsCtrlrPropGainInLatCtrl = AUTOSAR.Parameter;
LCA_LocalOffsCtrlrPropGainInLatCtrl.Value = [.25 .25 .6 .7 .7 .7 .7 .7];  % [5 10 25 50 75 100 125 150]km/h
LCA_LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.Alias = '';
LCA_LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_LocalOffsCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_LocalOffsCtrlrPropGainInLatCtrl.Description = '';
LCA_LocalOffsCtrlrPropGainInLatCtrl.DataType = 'single';
LCA_LocalOffsCtrlrPropGainInLatCtrl.Min = -7;
LCA_LocalOffsCtrlrPropGainInLatCtrl.Max = 7;
LCA_LocalOffsCtrlrPropGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LocalOffsCtrlPropGainRiInLatCtrl %
LocalOffsCtrlPropGainRiInLatCtrl = AUTOSAR.Parameter;
% LocalOffsCtrlPropGainRiInLatCtrl.Value = [.25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7 ; .25 .25 .6 .7 .7 .7];
LocalOffsCtrlPropGainRiInLatCtrl.Value = [.25 .25 .6 .9 1.05 1.2 1.35 1.5];  % [5 10 25 50 75 100 125 150]km/h
LocalOffsCtrlPropGainRiInLatCtrl.RTWInfo.StorageClass = 'Custom';
LocalOffsCtrlPropGainRiInLatCtrl.RTWInfo.Alias = '';
LocalOffsCtrlPropGainRiInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LocalOffsCtrlPropGainRiInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LocalOffsCtrlPropGainRiInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LocalOffsCtrlPropGainRiInLatCtrl.Description = '';
LocalOffsCtrlPropGainRiInLatCtrl.DataType = 'single';
LocalOffsCtrlPropGainRiInLatCtrl.Min = -7;
LocalOffsCtrlPropGainRiInLatCtrl.Max = 7;
LocalOffsCtrlPropGainRiInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VLatCtrlrPropGainInLatCtrl %
VLatCtrlrPropGainInLatCtrl = AUTOSAR.Parameter;
% VLatCtrlrPropGainInLatCtrl.Value = [.6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8 ; .6 .6 2.2 3.6 2.4 1.8];
VLatCtrlrPropGainInLatCtrl.Value = [.6 .6 2.2 3.6 3.4 3.0 2.7 2.4];         % [5 10 25 50 75 100 125 150]km/h
VLatCtrlrPropGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
VLatCtrlrPropGainInLatCtrl.RTWInfo.Alias = '';
VLatCtrlrPropGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VLatCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VLatCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VLatCtrlrPropGainInLatCtrl.Description = '';
VLatCtrlrPropGainInLatCtrl.DataType = 'single';
VLatCtrlrPropGainInLatCtrl.Min = -36;
VLatCtrlrPropGainInLatCtrl.Max = 36;
VLatCtrlrPropGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_VLatCtrlrPropGainInLatCtrl %
LCA_VLatCtrlrPropGainInLatCtrl = AUTOSAR.Parameter;
LCA_VLatCtrlrPropGainInLatCtrl.Value = [.6 .6 2.2 3.6 3.4 3.0 2.7 2.4];     % [5 10 25 50 75 100 125 150]km/h
LCA_VLatCtrlrPropGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_VLatCtrlrPropGainInLatCtrl.RTWInfo.Alias = '';
LCA_VLatCtrlrPropGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_VLatCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_VLatCtrlrPropGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_VLatCtrlrPropGainInLatCtrl.Description = '';
LCA_VLatCtrlrPropGainInLatCtrl.DataType = 'single';
LCA_VLatCtrlrPropGainInLatCtrl.Min = -36;
LCA_VLatCtrlrPropGainInLatCtrl.Max = 36;
LCA_VLatCtrlrPropGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VLatCtrlrIntglGainInLatCtrl %
VLatCtrlrIntglGainInLatCtrl = AUTOSAR.Parameter;
% VLatCtrlrIntglGainInLatCtrl.Value = [0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5 ; 0 .02 1 1.75 .9 .5];
VLatCtrlrIntglGainInLatCtrl.Value = [0 .02 1.0 1.75 1.4 .9 0.75 .5];
VLatCtrlrIntglGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
VLatCtrlrIntglGainInLatCtrl.RTWInfo.Alias = '';
VLatCtrlrIntglGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VLatCtrlrIntglGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VLatCtrlrIntglGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VLatCtrlrIntglGainInLatCtrl.Description = '';
VLatCtrlrIntglGainInLatCtrl.DataType = 'single';
VLatCtrlrIntglGainInLatCtrl.Min = -17.5;
VLatCtrlrIntglGainInLatCtrl.Max = 17.5;
VLatCtrlrIntglGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_VLatCtrlrIntglGainInLatCtrl %
LCA_VLatCtrlrIntglGainInLatCtrl = AUTOSAR.Parameter;
LCA_VLatCtrlrIntglGainInLatCtrl.Value = [0 .02 1.0 1.75 1.4 .9 0.75 .5];
LCA_VLatCtrlrIntglGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_VLatCtrlrIntglGainInLatCtrl.RTWInfo.Alias = '';
LCA_VLatCtrlrIntglGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_VLatCtrlrIntglGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_VLatCtrlrIntglGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_VLatCtrlrIntglGainInLatCtrl.Description = '';
LCA_VLatCtrlrIntglGainInLatCtrl.DataType = 'single';
LCA_VLatCtrlrIntglGainInLatCtrl.Min = -17.5;
LCA_VLatCtrlrIntglGainInLatCtrl.Max = 17.5;
LCA_VLatCtrlrIntglGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VLatCtrlrDrvGainInLatCtrl %
VLatCtrlrDrvGainInLatCtrl = AUTOSAR.Parameter;
% VLatCtrlrDrvGainInLatCtrl.Value = [0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2 ; 0.00 .00 0.04 .5 .35 .2];
VLatCtrlrDrvGainInLatCtrl.Value = [0.00 0.00 0.04 0.5 0.4 0.35 0.3 0.2];
VLatCtrlrDrvGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
VLatCtrlrDrvGainInLatCtrl.RTWInfo.Alias = '';
VLatCtrlrDrvGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VLatCtrlrDrvGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VLatCtrlrDrvGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VLatCtrlrDrvGainInLatCtrl.Description = '';
VLatCtrlrDrvGainInLatCtrl.DataType = 'single';
VLatCtrlrDrvGainInLatCtrl.Min = -5;
VLatCtrlrDrvGainInLatCtrl.Max = 5;
VLatCtrlrDrvGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_VLatCtrlrDrvGainInLatCtrl %
LCA_VLatCtrlrDrvGainInLatCtrl = AUTOSAR.Parameter;
LCA_VLatCtrlrDrvGainInLatCtrl.Value = [0.00 0.00 0.05 0.6 0.8 0.6 0.5 0.3];
LCA_VLatCtrlrDrvGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_VLatCtrlrDrvGainInLatCtrl.RTWInfo.Alias = '';
LCA_VLatCtrlrDrvGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_VLatCtrlrDrvGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_VLatCtrlrDrvGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_VLatCtrlrDrvGainInLatCtrl.Description = '';
LCA_VLatCtrlrDrvGainInLatCtrl.DataType = 'single';
LCA_VLatCtrlrDrvGainInLatCtrl.Min = -5;
LCA_VLatCtrlrDrvGainInLatCtrl.Max = 5;
LCA_VLatCtrlrDrvGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowPassTauInLatCtrl %
LowPassTauInLatCtrl = AUTOSAR.Parameter;
%LowPassTauInLatCtrl.Value = [.2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05; .2 .2 .05 .05 .05 .05 .05 .05];
LowPassTauInLatCtrl.Value = [.2 .2 .05 .05 .05 .05 .05 .05];
LowPassTauInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowPassTauInLatCtrl.RTWInfo.Alias = '';
LowPassTauInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowPassTauInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowPassTauInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowPassTauInLatCtrl.Description = '';
LowPassTauInLatCtrl.DataType = 'single';
LowPassTauInLatCtrl.Min = -2;
LowPassTauInLatCtrl.Max = 2;
LowPassTauInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_LowPassTauInLatCtrl %
LCA_LowPassTauInLatCtrl = AUTOSAR.Parameter;
LCA_LowPassTauInLatCtrl.Value = [.2 .2 .05 .05 .05 .05 .05 .05];
LCA_LowPassTauInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_LowPassTauInLatCtrl.RTWInfo.Alias = '';
LCA_LowPassTauInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_LowPassTauInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_LowPassTauInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_LowPassTauInLatCtrl.Description = '';
LCA_LowPassTauInLatCtrl.DataType = 'single';
LCA_LowPassTauInLatCtrl.Min = -2;
LCA_LowPassTauInLatCtrl.Max = 2;
LCA_LowPassTauInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowPassTauRedFacInLatCtrl %
LowPassTauRedFacInLatCtrl = AUTOSAR.Parameter;
LowPassTauRedFacInLatCtrl.Value = [6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8];
LowPassTauRedFacInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowPassTauRedFacInLatCtrl.RTWInfo.Alias = '';
LowPassTauRedFacInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowPassTauRedFacInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowPassTauRedFacInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowPassTauRedFacInLatCtrl.Description = '';
LowPassTauRedFacInLatCtrl.DataType = 'single';
LowPassTauRedFacInLatCtrl.Min = -80;
LowPassTauRedFacInLatCtrl.Max = 80;
LowPassTauRedFacInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowPassTauFFInLatCtrl %
LowPassTauFFInLatCtrl = AUTOSAR.Parameter;
% LowPassTauFFInLatCtrl.Value = [.5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05; .5 .4 .15 .07 .06 .05 .05 0.05];
LowPassTauFFInLatCtrl.Value = [.5 .4 .15 .07 .06 .05 .05 0.05];
LowPassTauFFInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowPassTauFFInLatCtrl.RTWInfo.Alias = '';
LowPassTauFFInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowPassTauFFInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowPassTauFFInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowPassTauFFInLatCtrl.Description = '';
LowPassTauFFInLatCtrl.DataType = 'single';
LowPassTauFFInLatCtrl.Min = -5;
LowPassTauFFInLatCtrl.Max = 5;
LowPassTauFFInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_LowPassTauFFInLatCtrl %
LCA_LowPassTauFFInLatCtrl = AUTOSAR.Parameter;
LCA_LowPassTauFFInLatCtrl.Value = [.5 .4 .15 .07 .06 .05 .05 0.05];
LCA_LowPassTauFFInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_LowPassTauFFInLatCtrl.RTWInfo.Alias = '';
LCA_LowPassTauFFInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_LowPassTauFFInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_LowPassTauFFInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_LowPassTauFFInLatCtrl.Description = '';
LCA_LowPassTauFFInLatCtrl.DataType = 'single';
LCA_LowPassTauFFInLatCtrl.Min = -5;
LCA_LowPassTauFFInLatCtrl.Max = 5;
LCA_LowPassTauFFInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowPassTauFFRedFacInLatCtrl %
LowPassTauFFRedFacInLatCtrl = AUTOSAR.Parameter;
LowPassTauFFRedFacInLatCtrl.Value = [6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8 ; 6 6 6 6 6 6 6 8]*0.5;
LowPassTauFFRedFacInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowPassTauFFRedFacInLatCtrl.RTWInfo.Alias = '';
LowPassTauFFRedFacInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowPassTauFFRedFacInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowPassTauFFRedFacInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowPassTauFFRedFacInLatCtrl.Description = '';
LowPassTauFFRedFacInLatCtrl.DataType = 'single';
LowPassTauFFRedFacInLatCtrl.Min = -40;
LowPassTauFFRedFacInLatCtrl.Max = 40;
LowPassTauFFRedFacInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VHiForIntglActnInLatCtrl %
VHiForIntglActnInLatCtrl = AUTOSAR.Parameter;
VHiForIntglActnInLatCtrl.Value = [13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6 13/3.6];
VHiForIntglActnInLatCtrl.RTWInfo.StorageClass = 'Custom';
VHiForIntglActnInLatCtrl.RTWInfo.Alias = '';
VHiForIntglActnInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VHiForIntglActnInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VHiForIntglActnInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VHiForIntglActnInLatCtrl.Description = '';
VHiForIntglActnInLatCtrl.DataType = 'single';
VHiForIntglActnInLatCtrl.Min = -36.1111;
VHiForIntglActnInLatCtrl.Max = 36.1111;
VHiForIntglActnInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VHysForIntglActnInLatCtrl %
VHysForIntglActnInLatCtrl = AUTOSAR.Parameter;
VHysForIntglActnInLatCtrl.Value = [3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6 3/3.6];
VHysForIntglActnInLatCtrl.RTWInfo.StorageClass = 'Custom';
VHysForIntglActnInLatCtrl.RTWInfo.Alias = '';
VHysForIntglActnInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VHysForIntglActnInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VHysForIntglActnInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VHysForIntglActnInLatCtrl.Description = '';
VHysForIntglActnInLatCtrl.DataType = 'single';
VHysForIntglActnInLatCtrl.Min = -8.3333;
VHysForIntglActnInLatCtrl.Max = 8.3333;
VHysForIntglActnInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RampTiForIntglActnInLatCtrl %
RampTiForIntglActnInLatCtrl = AUTOSAR.Parameter;
RampTiForIntglActnInLatCtrl.Value = [3 3 3 3 3 3 3 3 3 3 3 3 3];
RampTiForIntglActnInLatCtrl.RTWInfo.StorageClass = 'Custom';
RampTiForIntglActnInLatCtrl.RTWInfo.Alias = '';
RampTiForIntglActnInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
RampTiForIntglActnInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
RampTiForIntglActnInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
RampTiForIntglActnInLatCtrl.Description = '';
RampTiForIntglActnInLatCtrl.DataType = 'single';
RampTiForIntglActnInLatCtrl.Min = -30;
RampTiForIntglActnInLatCtrl.Max = 30;
RampTiForIntglActnInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RampVWdthForIntglActnInLatCtrl %
RampVWdthForIntglActnInLatCtrl = AUTOSAR.Parameter;
RampVWdthForIntglActnInLatCtrl.Value = [10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6 10/3.6];
RampVWdthForIntglActnInLatCtrl.RTWInfo.StorageClass = 'Custom';
RampVWdthForIntglActnInLatCtrl.RTWInfo.Alias = '';
RampVWdthForIntglActnInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
RampVWdthForIntglActnInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
RampVWdthForIntglActnInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
RampVWdthForIntglActnInLatCtrl.Description = '';
RampVWdthForIntglActnInLatCtrl.DataType = 'single';
RampVWdthForIntglActnInLatCtrl.Min = -27.7778;
RampVWdthForIntglActnInLatCtrl.Max = 27.7778;
RampVWdthForIntglActnInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DelayForIntglActnInLatCtrl %
DelayForIntglActnInLatCtrl = AUTOSAR.Parameter;
DelayForIntglActnInLatCtrl.Value = [0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3];
DelayForIntglActnInLatCtrl.RTWInfo.StorageClass = 'Custom';
DelayForIntglActnInLatCtrl.RTWInfo.Alias = '';
DelayForIntglActnInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
DelayForIntglActnInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
DelayForIntglActnInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
DelayForIntglActnInLatCtrl.Description = '';
DelayForIntglActnInLatCtrl.DataType = 'single';
DelayForIntglActnInLatCtrl.Min = -3;
DelayForIntglActnInLatCtrl.Max = 3;
DelayForIntglActnInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VForLrgPahOffsLimInLatCtrl %
VForLrgPahOffsLimInLatCtrl = AUTOSAR.Parameter;
VForLrgPahOffsLimInLatCtrl.Value = [5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201 ; 5 10 25 50 100 150 200 201]/3.6;
VForLrgPahOffsLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
VForLrgPahOffsLimInLatCtrl.RTWInfo.Alias = '';
VForLrgPahOffsLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VForLrgPahOffsLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VForLrgPahOffsLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VForLrgPahOffsLimInLatCtrl.Description = '';
VForLrgPahOffsLimInLatCtrl.DataType = 'single';
VForLrgPahOffsLimInLatCtrl.Min = -558.3333;
VForLrgPahOffsLimInLatCtrl.Max = 558.3333;
VForLrgPahOffsLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ALatLimAddlInLatCtrl %
ALatLimAddlInLatCtrl = AUTOSAR.Parameter;
ALatLimAddlInLatCtrl.Value = [0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4 ; 0.6 1.2 2 3 4 4 4 4];
ALatLimAddlInLatCtrl.RTWInfo.StorageClass = 'Custom';
ALatLimAddlInLatCtrl.RTWInfo.Alias = '';
ALatLimAddlInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
ALatLimAddlInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
ALatLimAddlInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
ALatLimAddlInLatCtrl.Description = '';
ALatLimAddlInLatCtrl.DataType = 'single';
ALatLimAddlInLatCtrl.Min = -40;
ALatLimAddlInLatCtrl.Max = 40;
ALatLimAddlInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VLatLimInInLatCtrl %
VLatLimInInLatCtrl = AUTOSAR.Parameter;
VLatLimInInLatCtrl.Value = [1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4 ; 1 1 2 3 4 4 4 4]/10;
VLatLimInInLatCtrl.RTWInfo.StorageClass = 'Custom';
VLatLimInInLatCtrl.RTWInfo.Alias = '';
VLatLimInInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VLatLimInInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VLatLimInInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VLatLimInInLatCtrl.Description = '';
VLatLimInInLatCtrl.DataType = 'single';
VLatLimInInLatCtrl.Min = -4;
VLatLimInInLatCtrl.Max = 4;
VLatLimInInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VLatLimOutInLatCtrl %
VLatLimOutInLatCtrl = AUTOSAR.Parameter;
VLatLimOutInLatCtrl.Value = [1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6 ; 1 2 4 6 6 6 6 6]/10;
VLatLimOutInLatCtrl.RTWInfo.StorageClass = 'Custom';
VLatLimOutInLatCtrl.RTWInfo.Alias = '';
VLatLimOutInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VLatLimOutInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VLatLimOutInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VLatLimOutInLatCtrl.Description = '';
VLatLimOutInLatCtrl.DataType = 'single';
VLatLimOutInLatCtrl.Min = -6;
VLatLimOutInLatCtrl.Max = 6;
VLatLimOutInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LocalOffsForLimOutInLatCtrl %
LocalOffsForLimOutInLatCtrl = AUTOSAR.Parameter;
LocalOffsForLimOutInLatCtrl.Value = [1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5 ; 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5];
LocalOffsForLimOutInLatCtrl.RTWInfo.StorageClass = 'Custom';
LocalOffsForLimOutInLatCtrl.RTWInfo.Alias = '';
LocalOffsForLimOutInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LocalOffsForLimOutInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LocalOffsForLimOutInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LocalOffsForLimOutInLatCtrl.Description = '';
LocalOffsForLimOutInLatCtrl.DataType = 'single';
LocalOffsForLimOutInLatCtrl.Min = -15;
LocalOffsForLimOutInLatCtrl.Max = 15;
LocalOffsForLimOutInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowrSpdLimForVLatLim %
LowrSpdLimForVLatLim = AUTOSAR.Parameter;
LowrSpdLimForVLatLim.Value = [5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5 5/3.5];
LowrSpdLimForVLatLim.RTWInfo.StorageClass = 'Custom';
LowrSpdLimForVLatLim.RTWInfo.Alias = '';
LowrSpdLimForVLatLim.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowrSpdLimForVLatLim.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowrSpdLimForVLatLim.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowrSpdLimForVLatLim.Description = '';
LowrSpdLimForVLatLim.DataType = 'single';
LowrSpdLimForVLatLim.Min = -14.2857;
LowrSpdLimForVLatLim.Max = 14.2857;
LowrSpdLimForVLatLim.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DrvrInLoopThdInLatCtrl %
DrvrInLoopThdInLatCtrl = AUTOSAR.Parameter;
DrvrInLoopThdInLatCtrl.Value = [0.90 0.90 0.90 0.90 0.90 0.90 0.90 0.90 0.90 0.90 0.90 0.90 0.90];
DrvrInLoopThdInLatCtrl.RTWInfo.StorageClass = 'Custom';
DrvrInLoopThdInLatCtrl.RTWInfo.Alias = '';
DrvrInLoopThdInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
DrvrInLoopThdInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
DrvrInLoopThdInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
DrvrInLoopThdInLatCtrl.Description = '';
DrvrInLoopThdInLatCtrl.DataType = 'single';
DrvrInLoopThdInLatCtrl.Min = -9.9;
DrvrInLoopThdInLatCtrl.Max = 9.9;
DrvrInLoopThdInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NoIntvPinionAngleReqInLatCtrl %
NoIntvPinionAngleReqInLatCtrl = AUTOSAR.Parameter;
NoIntvPinionAngleReqInLatCtrl.Value = [14.5 14.5 14.5 14.5 14.5 14.5 14.5 14.5 14.5 14.5 14.5 14.5 14.5];
NoIntvPinionAngleReqInLatCtrl.RTWInfo.StorageClass = 'Custom';
NoIntvPinionAngleReqInLatCtrl.RTWInfo.Alias = '';
NoIntvPinionAngleReqInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
NoIntvPinionAngleReqInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
NoIntvPinionAngleReqInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
NoIntvPinionAngleReqInLatCtrl.Description = '';
NoIntvPinionAngleReqInLatCtrl.DataType = 'single';
NoIntvPinionAngleReqInLatCtrl.Min = -145;
NoIntvPinionAngleReqInLatCtrl.Max = 145;
NoIntvPinionAngleReqInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ManTstLocalOffsInLatCtrl %
ManTstLocalOffsInLatCtrl = AUTOSAR.Parameter;
ManTstLocalOffsInLatCtrl.Value =  0;
ManTstLocalOffsInLatCtrl.RTWInfo.StorageClass = 'Custom';
ManTstLocalOffsInLatCtrl.RTWInfo.Alias = '';
ManTstLocalOffsInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
ManTstLocalOffsInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
ManTstLocalOffsInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
ManTstLocalOffsInLatCtrl.Description = '';
ManTstLocalOffsInLatCtrl.DataType = 'single';
ManTstLocalOffsInLatCtrl.Min = -1000;
ManTstLocalOffsInLatCtrl.Max = 1000;
ManTstLocalOffsInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UseSlipCmpInLatCtrl %
UseSlipCmpInLatCtrl = AUTOSAR.Parameter;
UseSlipCmpInLatCtrl.Value = [true true true true true true true true true true true true true];
UseSlipCmpInLatCtrl.RTWInfo.StorageClass = 'Custom';
UseSlipCmpInLatCtrl.RTWInfo.Alias = '';
UseSlipCmpInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
UseSlipCmpInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
UseSlipCmpInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
UseSlipCmpInLatCtrl.Description = '';
UseSlipCmpInLatCtrl.DataType = 'boolean';
UseSlipCmpInLatCtrl.Min = 0;
UseSlipCmpInLatCtrl.Max = 1;
UseSlipCmpInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DisNonLinLimInLatCtrl %
DisNonLinLimInLatCtrl = AUTOSAR.Parameter;
DisNonLinLimInLatCtrl.Value = [false false false false false false false false false false false false false];
DisNonLinLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
DisNonLinLimInLatCtrl.RTWInfo.Alias = '';
DisNonLinLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
DisNonLinLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
DisNonLinLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
DisNonLinLimInLatCtrl.Description = '';
DisNonLinLimInLatCtrl.DataType = 'boolean';
DisNonLinLimInLatCtrl.Min = 0;
DisNonLinLimInLatCtrl.Max = 1;
DisNonLinLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowrPinionAgRateLimInLatCtrl %
LowrPinionAgRateLimInLatCtrl = AUTOSAR.Parameter;
LowrPinionAgRateLimInLatCtrl.Value = [20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10 ; 20 60 60 10]*pi/180;
% LowrPinionAgRateLimInLatCtrl.Value = [15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10 ; 15 60 60 10]*pi/180;
LowrPinionAgRateLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowrPinionAgRateLimInLatCtrl.RTWInfo.Alias = '';
LowrPinionAgRateLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowrPinionAgRateLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowrPinionAgRateLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowrPinionAgRateLimInLatCtrl.Description = '';
LowrPinionAgRateLimInLatCtrl.DataType = 'single';
LowrPinionAgRateLimInLatCtrl.Min = -10.472;
LowrPinionAgRateLimInLatCtrl.Max = 10.472;
LowrPinionAgRateLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowrDILPinionAgRateLimInLatCtrl %
LowrDILPinionAgRateLimInLatCtrl = AUTOSAR.Parameter;
LowrDILPinionAgRateLimInLatCtrl.Value = [500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10 ; 500 60 60 10]*pi/180;
LowrDILPinionAgRateLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowrDILPinionAgRateLimInLatCtrl.RTWInfo.Alias = '';
LowrDILPinionAgRateLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowrDILPinionAgRateLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowrDILPinionAgRateLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowrDILPinionAgRateLimInLatCtrl.Description = '';
LowrDILPinionAgRateLimInLatCtrl.DataType = 'single';
LowrDILPinionAgRateLimInLatCtrl.Min = -87.2665;
LowrDILPinionAgRateLimInLatCtrl.Max = 87.2665;
LowrDILPinionAgRateLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HighrPinionAgRateLimInLatCtrl %
HighrPinionAgRateLimInLatCtrl = AUTOSAR.Parameter;
HighrPinionAgRateLimInLatCtrl.Value =  [[60 60 30 30 20 20 20 20]' [600 600 600 600 600 600 600 600]' [600 600 600 600 600 600 600 600]' [600 600 600 600 600 600 600 600]']*pi/180;
HighrPinionAgRateLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
HighrPinionAgRateLimInLatCtrl.RTWInfo.Alias = '';
HighrPinionAgRateLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
HighrPinionAgRateLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
HighrPinionAgRateLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
HighrPinionAgRateLimInLatCtrl.Description = '';
HighrPinionAgRateLimInLatCtrl.DataType = 'single';
HighrPinionAgRateLimInLatCtrl.Min = -104.7198;
HighrPinionAgRateLimInLatCtrl.Max = 104.7198;
HighrPinionAgRateLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionAgRateLimRateInLatCtrl %
PinionAgRateLimRateInLatCtrl = AUTOSAR.Parameter;
PinionAgRateLimRateInLatCtrl.Value = [20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20 ; 20 20 20 20]*pi/180;
PinionAgRateLimRateInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionAgRateLimRateInLatCtrl.RTWInfo.Alias = '';
PinionAgRateLimRateInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionAgRateLimRateInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionAgRateLimRateInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionAgRateLimRateInLatCtrl.Description = '';
PinionAgRateLimRateInLatCtrl.DataType = 'single';
PinionAgRateLimRateInLatCtrl.Min = -3.4907;
PinionAgRateLimRateInLatCtrl.Max = 3.4907;
PinionAgRateLimRateInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VForPinionAgCtrlKpInLatCtrl %
VForPinionAgCtrlKpInLatCtrl = AUTOSAR.Parameter;
VForPinionAgCtrlKpInLatCtrl.Value = [0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200 ; 0 5 10 25 50 100 200]/3.6;
VForPinionAgCtrlKpInLatCtrl.RTWInfo.StorageClass = 'Custom';
VForPinionAgCtrlKpInLatCtrl.RTWInfo.Alias = '';
VForPinionAgCtrlKpInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VForPinionAgCtrlKpInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VForPinionAgCtrlKpInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VForPinionAgCtrlKpInLatCtrl.Description = '';
VForPinionAgCtrlKpInLatCtrl.DataType = 'single';
VForPinionAgCtrlKpInLatCtrl.Min = -555.5556;
VForPinionAgCtrlKpInLatCtrl.Max = 555.5556;
VForPinionAgCtrlKpInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionAgCtrlKpInLatCtrl %
PinionAgCtrlKpInLatCtrl = AUTOSAR.Parameter;
PinionAgCtrlKpInLatCtrl.Value = [5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5 ; 5 5 5 5 5 5 5];
PinionAgCtrlKpInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionAgCtrlKpInLatCtrl.RTWInfo.Alias = '';
PinionAgCtrlKpInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionAgCtrlKpInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionAgCtrlKpInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionAgCtrlKpInLatCtrl.Description = '';
PinionAgCtrlKpInLatCtrl.DataType = 'single';
PinionAgCtrlKpInLatCtrl.Min = -100;
PinionAgCtrlKpInLatCtrl.Max = 100;
PinionAgCtrlKpInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ManTstModInLatCtrl %
ManTstModInLatCtrl = AUTOSAR.Parameter;
ManTstModInLatCtrl.Value =  int8(0);
ManTstModInLatCtrl.RTWInfo.StorageClass = 'Custom';
ManTstModInLatCtrl.RTWInfo.Alias = '';
ManTstModInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
ManTstModInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
ManTstModInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
ManTstModInLatCtrl.Description = '';
ManTstModInLatCtrl.DataType = 'int8';
ManTstModInLatCtrl.Min = -128;
ManTstModInLatCtrl.Max = 127;
ManTstModInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ManTstPinionAgReqInLatCtrl %
ManTstPinionAgReqInLatCtrl = AUTOSAR.Parameter;
ManTstPinionAgReqInLatCtrl.Value =  0;
ManTstPinionAgReqInLatCtrl.RTWInfo.StorageClass = 'Custom';
ManTstPinionAgReqInLatCtrl.RTWInfo.Alias = '';
ManTstPinionAgReqInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
ManTstPinionAgReqInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
ManTstPinionAgReqInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
ManTstPinionAgReqInLatCtrl.Description = '';
ManTstPinionAgReqInLatCtrl.DataType = 'single';
ManTstPinionAgReqInLatCtrl.Min = -1000;
ManTstPinionAgReqInLatCtrl.Max = 1000;
ManTstPinionAgReqInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UseLaneFilInLatCtrl %
UseLaneFilInLatCtrl = AUTOSAR.Parameter;
UseLaneFilInLatCtrl.Value = [true true true true true true true true true true true true true];
UseLaneFilInLatCtrl.RTWInfo.StorageClass = 'Custom';
UseLaneFilInLatCtrl.RTWInfo.Alias = '';
UseLaneFilInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
UseLaneFilInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
UseLaneFilInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
UseLaneFilInLatCtrl.Description = '';
UseLaneFilInLatCtrl.DataType = 'boolean';
UseLaneFilInLatCtrl.Min = 0;
UseLaneFilInLatCtrl.Max = 1;
UseLaneFilInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionAngleLowPassTauInLatCtrl %
PinionAngleLowPassTauInLatCtrl = AUTOSAR.Parameter;
PinionAngleLowPassTauInLatCtrl.Value = [.07 .07 .07 .07 .07 .07 .07 .07 .07 .07 .07 .07 .07];
PinionAngleLowPassTauInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionAngleLowPassTauInLatCtrl.RTWInfo.Alias = '';
PinionAngleLowPassTauInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionAngleLowPassTauInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionAngleLowPassTauInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionAngleLowPassTauInLatCtrl.Description = '';
PinionAngleLowPassTauInLatCtrl.DataType = 'single';
PinionAngleLowPassTauInLatCtrl.Min = -0.7;
PinionAngleLowPassTauInLatCtrl.Max = 0.7;
PinionAngleLowPassTauInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UseYawRateRawInLatCtrl %
UseYawRateRawInLatCtrl = AUTOSAR.Parameter;
UseYawRateRawInLatCtrl.Value =  false;
UseYawRateRawInLatCtrl.RTWInfo.StorageClass = 'Custom';
UseYawRateRawInLatCtrl.RTWInfo.Alias = '';
UseYawRateRawInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
UseYawRateRawInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
UseYawRateRawInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
UseYawRateRawInLatCtrl.Description = '';
UseYawRateRawInLatCtrl.DataType = 'boolean';
UseYawRateRawInLatCtrl.Min = 0;
UseYawRateRawInLatCtrl.Max = 1;
UseYawRateRawInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VForBicycleMdlInLatCtrl %
VForBicycleMdlInLatCtrl = AUTOSAR.Parameter;
VForBicycleMdlInLatCtrl.Value = [6 10 20 30 50 100 130 201 ; 6 10 20 30 50 100 130 201 ; 6 10 20 30 50 100 130 201 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203 ; 6 10 20 30 50 100 130 201 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203 ; 5 10 30 60 200 201 202 203]/3.6;
VForBicycleMdlInLatCtrl.RTWInfo.StorageClass = 'Custom';
VForBicycleMdlInLatCtrl.RTWInfo.Alias = '';
VForBicycleMdlInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VForBicycleMdlInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VForBicycleMdlInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VForBicycleMdlInLatCtrl.Description = '';
VForBicycleMdlInLatCtrl.DataType = 'single';
VForBicycleMdlInLatCtrl.Min = -563.8889;
VForBicycleMdlInLatCtrl.Max = 563.8889;
VForBicycleMdlInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BicycleMdlCornrgStfnFrntInLatCtrl %
BicycleMdlCornrgStfnFrntInLatCtrl = AUTOSAR.Parameter;
BicycleMdlCornrgStfnFrntInLatCtrl.Value = [0.13223 0.2485 0.6517 0.7866 1.0340 1.3098 1.3098 1.3098 ; 0.13223 0.2485 0.6517 0.7866 1.0340 1.3098 1.3098 1.3098 ; 0.13223 0.2485 0.6517 0.7866 1.0340 1.3098 1.3098 1.3098 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.13223 0.2485 0.6517 0.7866 1.0340 1.3098 1.3098 1.3098 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259 ; 0.1905    0.3399    1.0745    1.4259 1.4259 1.4259 1.4259 1.4259]*1.0e+05;
BicycleMdlCornrgStfnFrntInLatCtrl.RTWInfo.StorageClass = 'Custom';
BicycleMdlCornrgStfnFrntInLatCtrl.RTWInfo.Alias = '';
BicycleMdlCornrgStfnFrntInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
BicycleMdlCornrgStfnFrntInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
BicycleMdlCornrgStfnFrntInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
BicycleMdlCornrgStfnFrntInLatCtrl.Description = '';
BicycleMdlCornrgStfnFrntInLatCtrl.DataType = 'single';
BicycleMdlCornrgStfnFrntInLatCtrl.Min = -1425900;
BicycleMdlCornrgStfnFrntInLatCtrl.Max = 1425900;
BicycleMdlCornrgStfnFrntInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BicycleMdlCornrgStfnReInLatCtrl %
BicycleMdlCornrgStfnReInLatCtrl = AUTOSAR.Parameter;
BicycleMdlCornrgStfnReInLatCtrl.Value = [0.036987 0.2334 0.8609 1.0939 1.3312 1.7169 1.7169 1.7169 ; 0.036987 0.2334 0.8609 1.0939 1.3312 1.7169 1.7169 1.7169 ; 0.036987 0.2334 0.8609 1.0939 1.3312 1.7169 1.7169 1.7169 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.036987 0.2334 0.8609 1.0939 1.3312 1.7169 1.7169 1.7169 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808 ; 0.2391    0.5836    1.9032    2.2808 2.2808 2.2808 2.2808 2.2808]*1.0e+05;
BicycleMdlCornrgStfnReInLatCtrl.RTWInfo.StorageClass = 'Custom';
BicycleMdlCornrgStfnReInLatCtrl.RTWInfo.Alias = '';
BicycleMdlCornrgStfnReInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
BicycleMdlCornrgStfnReInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
BicycleMdlCornrgStfnReInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
BicycleMdlCornrgStfnReInLatCtrl.Description = '';
BicycleMdlCornrgStfnReInLatCtrl.DataType = 'single';
BicycleMdlCornrgStfnReInLatCtrl.Min = -2280800;
BicycleMdlCornrgStfnReInLatCtrl.Max = 2280800;
BicycleMdlCornrgStfnReInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BicycleMdlSteerRatInLatCtrl %
BicycleMdlSteerRatInLatCtrl = AUTOSAR.Parameter;
BicycleMdlSteerRatInLatCtrl.Value = [15.5 15.5 15.5 17.3 17.3 15.5 17.3 17.3 17.3 17.3 17.3 17.3 17.3];
BicycleMdlSteerRatInLatCtrl.RTWInfo.StorageClass = 'Custom';
BicycleMdlSteerRatInLatCtrl.RTWInfo.Alias = '';
BicycleMdlSteerRatInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
BicycleMdlSteerRatInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
BicycleMdlSteerRatInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
BicycleMdlSteerRatInLatCtrl.Description = '';
BicycleMdlSteerRatInLatCtrl.DataType = 'single';
BicycleMdlSteerRatInLatCtrl.Min = -173;
BicycleMdlSteerRatInLatCtrl.Max = 173;
BicycleMdlSteerRatInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionActvtyFiltSOSInLatCtrl %
PinionActvtyFiltSOSInLatCtrl = AUTOSAR.Parameter;
PinionActvtyFiltSOSInLatCtrl.Value =  [[1 -2 1 1 -1.964133571289337   0.968017003294617]' [1 -2 1 1 -1.911197067426073   0.914975834801434]' [1 -2 1 1 -1.881913547531161   0.885634416319557]']';
PinionActvtyFiltSOSInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionActvtyFiltSOSInLatCtrl.RTWInfo.Alias = '';
PinionActvtyFiltSOSInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionActvtyFiltSOSInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionActvtyFiltSOSInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionActvtyFiltSOSInLatCtrl.Description = '';
PinionActvtyFiltSOSInLatCtrl.DataType = 'single';
PinionActvtyFiltSOSInLatCtrl.Min = -20;
PinionActvtyFiltSOSInLatCtrl.Max = 20;
PinionActvtyFiltSOSInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionActvtyFiltGInLatCtrl %
PinionActvtyFiltGInLatCtrl = AUTOSAR.Parameter;
PinionActvtyFiltGInLatCtrl.Value =  [0.983037643645988   0.956543225556877   0.941886990962680   1.000000000000000];
PinionActvtyFiltGInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionActvtyFiltGInLatCtrl.RTWInfo.Alias = '';
PinionActvtyFiltGInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionActvtyFiltGInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionActvtyFiltGInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionActvtyFiltGInLatCtrl.Description = '';
PinionActvtyFiltGInLatCtrl.DataType = 'single';
PinionActvtyFiltGInLatCtrl.Min = -10;
PinionActvtyFiltGInLatCtrl.Max = 10;
PinionActvtyFiltGInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionRMSAvgTInLatCtrl %
PinionRMSAvgTInLatCtrl = AUTOSAR.Parameter;
PinionRMSAvgTInLatCtrl.Value =  [1 10];
PinionRMSAvgTInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionRMSAvgTInLatCtrl.RTWInfo.Alias = '';
PinionRMSAvgTInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionRMSAvgTInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionRMSAvgTInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionRMSAvgTInLatCtrl.Description = '';
PinionRMSAvgTInLatCtrl.DataType = 'single';
PinionRMSAvgTInLatCtrl.Min = -100;
PinionRMSAvgTInLatCtrl.Max = 100;
PinionRMSAvgTInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionRMSForHigrActvtyInLatCtrl %
PinionRMSForHigrActvtyInLatCtrl = AUTOSAR.Parameter;
PinionRMSForHigrActvtyInLatCtrl.Value = [1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180 1*pi/180];
PinionRMSForHigrActvtyInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionRMSForHigrActvtyInLatCtrl.RTWInfo.Alias = '';
PinionRMSForHigrActvtyInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionRMSForHigrActvtyInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionRMSForHigrActvtyInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionRMSForHigrActvtyInLatCtrl.Description = '';
PinionRMSForHigrActvtyInLatCtrl.DataType = 'single';
PinionRMSForHigrActvtyInLatCtrl.Min = -0.17453;
PinionRMSForHigrActvtyInLatCtrl.Max = 0.17453;
PinionRMSForHigrActvtyInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionActvtyTrgtValInLatCtrl %
PinionActvtyTrgtValInLatCtrl = AUTOSAR.Parameter;
PinionActvtyTrgtValInLatCtrl.Value = [.3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2; .3 .3 .3 .3 .25 .2 .2 .2];
PinionActvtyTrgtValInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionActvtyTrgtValInLatCtrl.RTWInfo.Alias = '';
PinionActvtyTrgtValInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionActvtyTrgtValInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionActvtyTrgtValInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionActvtyTrgtValInLatCtrl.Description = '';
PinionActvtyTrgtValInLatCtrl.DataType = 'single';
PinionActvtyTrgtValInLatCtrl.Min = -3;
PinionActvtyTrgtValInLatCtrl.Max = 3;
PinionActvtyTrgtValInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TunFacCtrlrLocalOffsThdInLatCtrl %
TunFacCtrlrLocalOffsThdInLatCtrl = AUTOSAR.Parameter;
TunFacCtrlrLocalOffsThdInLatCtrl.Value = [.15 .15 .15 .15 .15 .15 .15 .15 .15 .15 .15 .15 .15];
TunFacCtrlrLocalOffsThdInLatCtrl.RTWInfo.StorageClass = 'Custom';
TunFacCtrlrLocalOffsThdInLatCtrl.RTWInfo.Alias = '';
TunFacCtrlrLocalOffsThdInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
TunFacCtrlrLocalOffsThdInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
TunFacCtrlrLocalOffsThdInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
TunFacCtrlrLocalOffsThdInLatCtrl.Description = '';
TunFacCtrlrLocalOffsThdInLatCtrl.DataType = 'single';
TunFacCtrlrLocalOffsThdInLatCtrl.Min = -1.5;
TunFacCtrlrLocalOffsThdInLatCtrl.Max = 1.5;
TunFacCtrlrLocalOffsThdInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TunFacCtrlrLocalOffsGainInLatCtrl %
TunFacCtrlrLocalOffsGainInLatCtrl = AUTOSAR.Parameter;
TunFacCtrlrLocalOffsGainInLatCtrl.Value = [.1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1];
TunFacCtrlrLocalOffsGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
TunFacCtrlrLocalOffsGainInLatCtrl.RTWInfo.Alias = '';
TunFacCtrlrLocalOffsGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
TunFacCtrlrLocalOffsGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
TunFacCtrlrLocalOffsGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
TunFacCtrlrLocalOffsGainInLatCtrl.Description = '';
TunFacCtrlrLocalOffsGainInLatCtrl.DataType = 'single';
TunFacCtrlrLocalOffsGainInLatCtrl.Min = -1;
TunFacCtrlrLocalOffsGainInLatCtrl.Max = 1;
TunFacCtrlrLocalOffsGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TunFacCtrlrActvtyGainInLatCtrl %
TunFacCtrlrActvtyGainInLatCtrl = AUTOSAR.Parameter;
TunFacCtrlrActvtyGainInLatCtrl.Value = [.05 .05 .05 .05 .05 .05 .05 .05 .05 .05 .05 .05 .05];
TunFacCtrlrActvtyGainInLatCtrl.RTWInfo.StorageClass = 'Custom';
TunFacCtrlrActvtyGainInLatCtrl.RTWInfo.Alias = '';
TunFacCtrlrActvtyGainInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
TunFacCtrlrActvtyGainInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
TunFacCtrlrActvtyGainInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
TunFacCtrlrActvtyGainInLatCtrl.Description = '';
TunFacCtrlrActvtyGainInLatCtrl.DataType = 'single';
TunFacCtrlrActvtyGainInLatCtrl.Min = -0.5;
TunFacCtrlrActvtyGainInLatCtrl.Max = 0.5;
TunFacCtrlrActvtyGainInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PinionActvtyCtrlrLimInLatCtrl %
PinionActvtyCtrlrLimInLatCtrl = AUTOSAR.Parameter;
PinionActvtyCtrlrLimInLatCtrl.Value = [.85 .85 .85 .85 .85 .85 .85 .85 .85 .85 .85 .85 .85];
PinionActvtyCtrlrLimInLatCtrl.RTWInfo.StorageClass = 'Custom';
PinionActvtyCtrlrLimInLatCtrl.RTWInfo.Alias = '';
PinionActvtyCtrlrLimInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
PinionActvtyCtrlrLimInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
PinionActvtyCtrlrLimInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
PinionActvtyCtrlrLimInLatCtrl.Description = '';
PinionActvtyCtrlrLimInLatCtrl.DataType = 'single';
PinionActvtyCtrlrLimInLatCtrl.Min = -8.5;
PinionActvtyCtrlrLimInLatCtrl.Max = 8.5;
PinionActvtyCtrlrLimInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ManTunFacInLatCtrl %
ManTunFacInLatCtrl = AUTOSAR.Parameter;
ManTunFacInLatCtrl.Value =  [-1.0 0.9 0.9 .8];
ManTunFacInLatCtrl.RTWInfo.StorageClass = 'Custom';
ManTunFacInLatCtrl.RTWInfo.Alias = '';
ManTunFacInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
ManTunFacInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
ManTunFacInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
ManTunFacInLatCtrl.Description = '';
ManTunFacInLatCtrl.DataType = 'single';
ManTunFacInLatCtrl.Min = -10;
ManTunFacInLatCtrl.Max = 10;
ManTunFacInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MinTunFacInLatCtrl %
MinTunFacInLatCtrl = AUTOSAR.Parameter;
MinTunFacInLatCtrl.Value = [.499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8; .499 .549 .699 .751 0.775 .8 .8 .8];
MinTunFacInLatCtrl.RTWInfo.StorageClass = 'Custom';
MinTunFacInLatCtrl.RTWInfo.Alias = '';
MinTunFacInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
MinTunFacInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
MinTunFacInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
MinTunFacInLatCtrl.Description = '';
MinTunFacInLatCtrl.DataType = 'single';
MinTunFacInLatCtrl.Min = -8;
MinTunFacInLatCtrl.Max = 8;
MinTunFacInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MaxTunFacInLatCtrl %
MaxTunFacInLatCtrl = AUTOSAR.Parameter;
MaxTunFacInLatCtrl.Value = [.5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9; .5 .55 .7 .9 .9 .9 .9 .9];
MaxTunFacInLatCtrl.RTWInfo.StorageClass = 'Custom';
MaxTunFacInLatCtrl.RTWInfo.Alias = '';
MaxTunFacInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
MaxTunFacInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
MaxTunFacInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
MaxTunFacInLatCtrl.Description = '';
MaxTunFacInLatCtrl.DataType = 'single';
MaxTunFacInLatCtrl.Min = -9;
MaxTunFacInLatCtrl.Max = 9;
MaxTunFacInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MaxTunFacDILInLatCtrl %
MaxTunFacDILInLatCtrl = AUTOSAR.Parameter;
MaxTunFacDILInLatCtrl.Value = [.8 .8 .8 .8 .8 .8 .8 .8 .8 .8 .8 .8 .8];
MaxTunFacDILInLatCtrl.RTWInfo.StorageClass = 'Custom';
MaxTunFacDILInLatCtrl.RTWInfo.Alias = '';
MaxTunFacDILInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
MaxTunFacDILInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
MaxTunFacDILInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
MaxTunFacDILInLatCtrl.Description = '';
MaxTunFacDILInLatCtrl.DataType = 'single';
MaxTunFacDILInLatCtrl.Min = -8;
MaxTunFacDILInLatCtrl.Max = 8;
MaxTunFacDILInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MaxTunFacDILRateInLatCtrl %
MaxTunFacDILRateInLatCtrl = AUTOSAR.Parameter;
MaxTunFacDILRateInLatCtrl.Value = [.1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1 .1];
MaxTunFacDILRateInLatCtrl.RTWInfo.StorageClass = 'Custom';
MaxTunFacDILRateInLatCtrl.RTWInfo.Alias = '';
MaxTunFacDILRateInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
MaxTunFacDILRateInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
MaxTunFacDILRateInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
MaxTunFacDILRateInLatCtrl.Description = '';
MaxTunFacDILRateInLatCtrl.DataType = 'single';
MaxTunFacDILRateInLatCtrl.Min = -1;
MaxTunFacDILRateInLatCtrl.Max = 1;
MaxTunFacDILRateInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MaxTunFacDILDelayInLatCtrl %
MaxTunFacDILDelayInLatCtrl = AUTOSAR.Parameter;
MaxTunFacDILDelayInLatCtrl.Value = [10 10 10 10 10 10 10 10 10 10 10 10 10];
MaxTunFacDILDelayInLatCtrl.RTWInfo.StorageClass = 'Custom';
MaxTunFacDILDelayInLatCtrl.RTWInfo.Alias = '';
MaxTunFacDILDelayInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
MaxTunFacDILDelayInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
MaxTunFacDILDelayInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
MaxTunFacDILDelayInLatCtrl.Description = '';
MaxTunFacDILDelayInLatCtrl.DataType = 'single';
MaxTunFacDILDelayInLatCtrl.Min = -100;
MaxTunFacDILDelayInLatCtrl.Max = 100;
MaxTunFacDILDelayInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TunFacEffRangeInLatCtrl %
TunFacEffRangeInLatCtrl = AUTOSAR.Parameter;
TunFacEffRangeInLatCtrl.Value = [8 8 8 8 8 8 8 8 8 8 8 8 8];
TunFacEffRangeInLatCtrl.RTWInfo.StorageClass = 'Custom';
TunFacEffRangeInLatCtrl.RTWInfo.Alias = '';
TunFacEffRangeInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
TunFacEffRangeInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
TunFacEffRangeInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
TunFacEffRangeInLatCtrl.Description = '';
TunFacEffRangeInLatCtrl.DataType = 'single';
TunFacEffRangeInLatCtrl.Min = -80;
TunFacEffRangeInLatCtrl.Max = 80;
TunFacEffRangeInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LowrSpdLimforPathExtrapInLatCtrl %
LowrSpdLimforPathExtrapInLatCtrl = AUTOSAR.Parameter;
LowrSpdLimforPathExtrapInLatCtrl.Value = [30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6 30/3.6];
LowrSpdLimforPathExtrapInLatCtrl.RTWInfo.StorageClass = 'Custom';
LowrSpdLimforPathExtrapInLatCtrl.RTWInfo.Alias = '';
LowrSpdLimforPathExtrapInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LowrSpdLimforPathExtrapInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LowrSpdLimforPathExtrapInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LowrSpdLimforPathExtrapInLatCtrl.Description = '';
LowrSpdLimforPathExtrapInLatCtrl.DataType = 'single';
LowrSpdLimforPathExtrapInLatCtrl.Min = -83.3333;
LowrSpdLimforPathExtrapInLatCtrl.Max = 83.3333;
LowrSpdLimforPathExtrapInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% VForFFGainTunInLatCtrl %
VForFFGainTunInLatCtrl = AUTOSAR.Parameter;
% VForFFGainTunInLatCtrl.Value = [5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150 ; 5 10 25 50 75 100 150]/3.6;
VForFFGainTunInLatCtrl.Value = [5 10 25 50 75 100 150]/3.6;
VForFFGainTunInLatCtrl.RTWInfo.StorageClass = 'Custom';
VForFFGainTunInLatCtrl.RTWInfo.Alias = '';
VForFFGainTunInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
VForFFGainTunInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
VForFFGainTunInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
VForFFGainTunInLatCtrl.Description = '';
VForFFGainTunInLatCtrl.DataType = 'single';
VForFFGainTunInLatCtrl.Min = -416.6667;
VForFFGainTunInLatCtrl.Max = 416.6667;
VForFFGainTunInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FFGainTunInLatCtrl %
FFGainTunInLatCtrl = AUTOSAR.Parameter;
% FFGainTunInLatCtrl.Value = [1 1 1 1 1 1 1 ; 1 1 1 1 1 1 1 ; 1 1 1 1 1 1 1 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 1 1 1 1 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7 ; 1 1 1 0.9 0.7 0.7 0.7];
FFGainTunInLatCtrl.Value = [1.0 1.0 1.0 1.0 1.0 1.0 1.0];
FFGainTunInLatCtrl.RTWInfo.StorageClass = 'Custom';
FFGainTunInLatCtrl.RTWInfo.Alias = '';
FFGainTunInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
FFGainTunInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
FFGainTunInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
FFGainTunInLatCtrl.Description = '';
FFGainTunInLatCtrl.DataType = 'single';
FFGainTunInLatCtrl.Min = -10;
FFGainTunInLatCtrl.Max = 10;
FFGainTunInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LCA_FFGainTunInLatCtrl %
LCA_FFGainTunInLatCtrl = AUTOSAR.Parameter;
LCA_FFGainTunInLatCtrl.Value = [1.0 1.0 1.0 1.0 1.0 1.0 1.0];
LCA_FFGainTunInLatCtrl.RTWInfo.StorageClass = 'Custom';
LCA_FFGainTunInLatCtrl.RTWInfo.Alias = '';
LCA_FFGainTunInLatCtrl.RTWInfo.CustomStorageClass = 'InternalCalPrm';
LCA_FFGainTunInLatCtrl.RTWInfo.CustomAttributes.SwCalibrationAccess = 'READ-WRITE';
LCA_FFGainTunInLatCtrl.RTWInfo.CustomAttributes.PerInstanceBehavior = 'Parameter shared by all instances of the Software Component';
LCA_FFGainTunInLatCtrl.Description = '';
LCA_FFGainTunInLatCtrl.DataType = 'single';
LCA_FFGainTunInLatCtrl.Min = -10;
LCA_FFGainTunInLatCtrl.Max = 10;
LCA_FFGainTunInLatCtrl.DocUnits = '';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%