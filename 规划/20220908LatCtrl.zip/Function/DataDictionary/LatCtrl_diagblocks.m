% Initialization of diagtool blocks for host logs
DiagtoolBlocks.DIAG_LatCtrl_LocalOffset = true;
DiagtoolBlocks.DIAG_LatCtrl_LookAheadEffectiveTime = true;
DiagtoolBlocks.DIAG_LatCtrl_AsyPinionAgReq = true;
DiagtoolBlocks.DIAG_LatCtrl_LookAheadEffectiveDistance = true;
DiagtoolBlocks.DIAG_LatCtrl_ViewRange = true;
DiagtoolBlocks.DIAG_LatCtrl_CurvatureDesired = true;
DiagtoolBlocks.DIAG_LatCtrl_SteerActivity = true;
DiagtoolBlocks.DIAG_LatCtrl_TuningFactor = true;
DiagtoolBlocks.DIAG_LatCtrl_PinionAngleRequestFF = true;
DiagtoolBlocks.DIAG_LatCtrl_PinionAngleRequestFB = true;

DiagtoolDataTypes.LOG_LatCtrl_VLatPPart = 'single';
DiagtoolInitialValue.LOG_LatCtrl_VLatPPart = '0';
DiagtoolBlocks.LOG_LatCtrl_VLatPPart = true; 

DiagtoolDataTypes.LOG_LatCtrl_VLatIPart = 'single';
DiagtoolInitialValue.LOG_LatCtrl_VLatIPart = '0';
DiagtoolBlocks.LOG_LatCtrl_VLatIPart = true;

DiagtoolDataTypes.LOG_LatCtrl_VLatDPart = 'single';
DiagtoolInitialValue.LOG_LatCtrl_VLatDPart = '0';
DiagtoolBlocks.LOG_LatCtrl_VLatDPart = true;

DiagtoolDataTypes.LOG_LatCtrl_LocalOffset = 'single';
DiagtoolInitialValue.LOG_LatCtrl_LocalOffset = '0';
DiagtoolBlocks.LOG_LatCtrl_LocalOffset = true;

DiagtoolDataTypes.LOG_LatCtrl_LookAheadOffset = 'single';
DiagtoolInitialValue.LOG_LatCtrl_LookAheadOffset = '0';
DiagtoolBlocks.LOG_LatCtrl_LookAheadOffset = true;

DiagtoolDataTypes.LOG_LatCtrl_LookAheadEffectiveDistance = 'single';
DiagtoolInitialValue.LOG_LatCtrl_LookAheadEffectiveDistance = '0';
DiagtoolBlocks.LOG_LatCtrl_LookAheadEffectiveDistance = true;

DiagtoolDataTypes.LOG_LatCtrl_LocalHeading = 'single';
DiagtoolInitialValue.LOG_LatCtrl_LocalHeading = '0';
DiagtoolBlocks.LOG_LatCtrl_LocalHeading = true;

DiagtoolDataTypes.LOG_LatCtrl_ViewRange = 'single';
DiagtoolInitialValue.LOG_LatCtrl_ViewRange = '0';
DiagtoolBlocks.LOG_LatCtrl_ViewRange = true;

DiagtoolDataTypes.LOG_LatCtrl_TuningFactor = 'single';
DiagtoolInitialValue.LOG_LatCtrl_TuningFactor = '0';
DiagtoolBlocks.LOG_LatCtrl_TuningFactor = true;

DiagtoolDataTypes.LOG_LatCtrl_SteerActivity = 'single';
DiagtoolInitialValue.LOG_LatCtrl_SteerActivity = '0';
DiagtoolBlocks.LOG_LatCtrl_SteerActivity = true;

DiagtoolDataTypes.LOG_LatCtrl_LookAheadEffectiveTime = 'single';
DiagtoolInitialValue.LOG_LatCtrl_LookAheadEffectiveTime = '0';
DiagtoolBlocks.LOG_LatCtrl_LookAheadEffectiveTime = true;

DiagtoolDataTypes.LOG_LatCtrl_PinionAngleRequestFB = 'single';
DiagtoolInitialValue.LOG_LatCtrl_PinionAngleRequestFB = '0';
DiagtoolBlocks.LOG_LatCtrl_PinionAngleRequestFB = true;

DiagtoolDataTypes.LOG_LatCtrl_PinionAngleRequestFF = 'single';
DiagtoolInitialValue.LOG_LatCtrl_PinionAngleRequestFF = '0';
DiagtoolBlocks.LOG_LatCtrl_PinionAngleRequestFF = true;

DiagtoolDataTypes.LOG_LatCtrl_PinionAngleRequest = 'single';
DiagtoolInitialValue.LOG_LatCtrl_PinionAngleRequest = '0';
DiagtoolBlocks.LOG_LatCtrl_PinionAngleRequest = true;

DiagtoolDataTypes.LOG_LatCtrl_TorqueLimitActivation = 'boolean';
DiagtoolInitialValue.LOG_LatCtrl_TorqueLimitActivation = 'false';
DiagtoolBlocks.LOG_LatCtrl_TorqueLimitActivation = true;