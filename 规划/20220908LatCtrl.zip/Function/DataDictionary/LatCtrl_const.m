TiStepInLatCtrl = single(0.025);
LatCtrl_development_type=uint8(2);

% %%%VehicleType=6 for V541, VehicleType=4 for V526;
% VehicleType=single(6);
% BicycleMdlMInLatCtrl_S90=single(1790);
% % BicycleMdlMInLatCtrl_XC90=single(1878); %%old incorrect
% BicycleMdlMInLatCtrl_XC90=single(2164);
% 
% BicycleMdlJInLatCtrl_S90=single(3572);
% % BicycleMdlJInLatCtrl_XC90=single(3054); %%old incorrect
% BicycleMdlJInLatCtrl_XC90=single(4373);
% 
% BicycleMdlAxleDistFrntInLatCtrl_S90=single(1.1098);
% % BicycleMdlAxleDistFrntInLatCtrl_XC90=single(1.19); %%old incorrect
% BicycleMdlAxleDistFrntInLatCtrl_XC90=single(1.3384);
% 
% BicycleMdlWhlBasInLatCtrl_S90=single(2.72);
% % BicycleMdlWhlBasInLatCtrl_XC90=single(2.78); %%old incorrect
% BicycleMdlWhlBasInLatCtrl_XC90=single(2.9840);
% 
% BicycleMdlSteerRatInLatCtrl_S90=single(15.5);
% BicycleMdlSteerRatInLatCtrl_XC90=single(17.3);