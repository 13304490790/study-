% Local constants file for LatCtrl do not change
%
% NOTE: This file shall be checked in if used!

LatCtrl_func_datatypes;

LatCtrlSampleTime = single(0.025);

vcc.simulink.parameterAutosar2Normal('LatCtrl_cal.m');

LatCtrl_func_custom_init;

