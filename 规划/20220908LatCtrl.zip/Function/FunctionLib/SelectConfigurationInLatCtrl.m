function [HdWayNomInLatCtrl_out,HdWayMinInLatCtrl_out,LowrSpdLimInLatCtrl_out,...
    LowrSpdLimSmthFacInLatCtrl_out, EvnLowrSpdLimInLatCtrl_out,VForLinTunInLatCtrl_out,...
    LocalOffsCtrlrPropGainInLatCtrl_out,VLatCtrlrPropGainInLatCtrl_out,PinionActvtyFiltSOSInLatCtrl_out,...
    LowPassTauInLatCtrl_out, VHiForIntglActnInLatCtrl_out,VHysForIntglActnInLatCtrl_out,...
    RampTiForIntglActnInLatCtrl_out,PinionActvtyFiltGInLatCtrl_out,VForLrgPahOffsLimInLatCtrl_out,...
    ALatLimAddlInLatCtrl_out,VLatLimInInLatCtrl_out,VLatLimOutInLatCtrl_out,...
    LocalOffsForLimOutInLatCtrl_out,DrvrInLoopThdInLatCtrl_out, NoIntvPinionAngleReqInLatCtrl_out,...
    ManTstLocalOffsInLatCtrl_out,UseSlipCmpInLatCtrl_out,DisNonLinLimInLatCtrl_out,...
    PinionActvtyTrgtValInLatCtrl_out,VForPinionAgCtrlKpInLatCtrl_out,PinionAgCtrlKpInLatCtrl_out,...
    ManTstModInLatCtrl_out,ManTstPinionAgReqInLatCtrl_out,UseLaneFilInLatCtrl_out,...
    TunFacCtrlrLocalOffsGainInLatCtrl_out,VLatCtrlrIntglGainInLatCtrl_out,PinionRMSForHigrActvtyInLatCtrl_out,...
    PinionActvtyCtrlrLimInLatCtrl_out,LowrSpdLimForVLatLim_out,TiStepInLatCtrl_out,...
    LowrPinionAgRateLimInLatCtrl_out,HighrPinionAgRateLimInLatCtrl_out,PinionAgRateLimRateInLatCtrl_out,...
    PinionAngleLowPassTauInLatCtrl_out,LowrDILPinionAgRateLimInLatCtrl_out,ManTunFacInLatCtrl_out,...
    DelayForIntglActnInLatCtrl_out,VLatCtrlrDrvGainInLatCtrl_out,LowPassTauRedFacInLatCtrl_out,...
    HdWayLongInLatCtrl_out,HdWayLongerInLatCtrl_out,MaxTunFacDILDelayInLatCtrl_out,...
    MinTunFacInLatCtrl_out,MaxTunFacInLatCtrl_out,TunFacEffRangeInLatCtrl_out,...
    MaxTunFacDILRateInLatCtrl_out, TunFacCtrlrActvtyGainInLatCtrl_out, TunFacCtrlrLocalOffsThdInLatCtrl_out,...
    LowPassTauFFInLatCtrl_out,LowPassTauFFRedFacInLatCtrl_out,MaxTunFacDILInLatCtrl_out,...
    RampVWdthForIntglActnInLatCtrl_out, LowrSpdLimforPathExtrapInLatCtrl_out,VForFFGainTunInLatCtrl_out,...
    FFGainTunInLatCtrl_out, bicycle_C_f_out,bicycle_C_r_out]...
    =SelectConfigurationInLatCtrl...
    (HdWayNomInLatCtrl,HdWayMinInLatCtrl,LowrSpdLimInLatCtrl,...
    LowrSpdLimSmthFacInLatCtrl, EvnLowrSpdLimInLatCtrl,VForLinTunInLatCtrl,...
    LocalOffsCtrlrPropGainInLatCtrl,VLatCtrlrPropGainInLatCtrl,PinionActvtyFiltSOSInLatCtrl,...
    LowPassTauInLatCtrl, VHiForIntglActnInLatCtrl,VHysForIntglActnInLatCtrl,...
    RampTiForIntglActnInLatCtrl,PinionActvtyFiltGInLatCtrl,VForLrgPahOffsLimInLatCtrl,...
    ALatLimAddlInLatCtrl,VLatLimInInLatCtrl,VLatLimOutInLatCtrl,...
    LocalOffsForLimOutInLatCtrl,DrvrInLoopThdInLatCtrl, NoIntvPinionAngleReqInLatCtrl,...
    ManTstLocalOffsInLatCtrl,UseSlipCmpInLatCtrl,DisNonLinLimInLatCtrl,...
    PinionActvtyTrgtValInLatCtrl,VForPinionAgCtrlKpInLatCtrl,PinionAgCtrlKpInLatCtrl,...
    ManTstModInLatCtrl,ManTstPinionAgReqInLatCtrl,UseLaneFilInLatCtrl,...
    TunFacCtrlrLocalOffsGainInLatCtrl,VLatCtrlrIntglGainInLatCtrl,PinionRMSForHigrActvtyInLatCtrl,...
    PinionActvtyCtrlrLimInLatCtrl,LowrSpdLimForVLatLim,TiStepInLatCtrl,...
    LowrPinionAgRateLimInLatCtrl,HighrPinionAgRateLimInLatCtrl,PinionAgRateLimRateInLatCtrl,...  
    PinionAngleLowPassTauInLatCtrl,LowrDILPinionAgRateLimInLatCtrl,ManTunFacInLatCtrl,...
    DelayForIntglActnInLatCtrl,VLatCtrlrDrvGainInLatCtrl,LowPassTauRedFacInLatCtrl,...
    HdWayLongInLatCtrl,HdWayLongerInLatCtrl,MaxTunFacDILDelayInLatCtrl,...
    MinTunFacInLatCtrl,MaxTunFacInLatCtrl,TunFacEffRangeInLatCtrl,...
    MaxTunFacDILRateInLatCtrl, TunFacCtrlrActvtyGainInLatCtrl, TunFacCtrlrLocalOffsThdInLatCtrl,...
    LowPassTauFFInLatCtrl,LowPassTauFFRedFacInLatCtrl,MaxTunFacDILInLatCtrl,...
    RampVWdthForIntglActnInLatCtrl, LowrSpdLimforPathExtrapInLatCtrl,VForFFGainTunInLatCtrl,...
    FFGainTunInLatCtrl,LCA_HdWayNomInLatCtrl, LCA_LocalOffsCtrlrPropGainInLatCtrl, ...
    LCA_VLatCtrlrPropGainInLatCtrl, LCA_VLatCtrlrIntglGainInLatCtrl, LCA_VLatCtrlrDrvGainInLatCtrl, ...
    LCA_FFGainTunInLatCtrl,LCA_LowPassTauInLatCtrl,LCA_LowPassTauFFInLatCtrl,VForBicycleMdlInLatCtrl, ...
    LateralControlModeRequestLimited,VehicleSpeed,BicycleMdlCornrgStfnFrntInLatCtrl,BicycleMdlCornrgStfnReInLatCtrl,...
    VehType, LCA_Executing)

%%%Description
%%%Selects configuration based on Vehicle type.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% A comment to please ModelAdvisor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

VehType=max(VehType, uint8(1)); %ensure VehType has a valid index
VehType=min(uint8(13), VehType);
%%%Preallocate memory
% HdWayNomInLatCtrl_out = zeros(1, 4, 'single');
HdWayMinInLatCtrl_out = zeros(1, 1, 'single');
LowrSpdLimInLatCtrl_out = zeros(1, 1, 'single');
LowrSpdLimSmthFacInLatCtrl_out = zeros(1, 1, 'single');
EvnLowrSpdLimInLatCtrl_out = zeros(1, 1, 'single');
VForLinTunInLatCtrl_out = zeros(1, 8, 'single');
% LocalOffsCtrlrPropGainInLatCtrl_out = zeros(1, 8, 'single');
% VLatCtrlrPropGainInLatCtrl_out = zeros(1, 8, 'single');
PinionActvtyFiltSOSInLatCtrl_out = zeros(3, 6, 'single');
% LowPassTauInLatCtrl_out = zeros(1, 8, 'single');
VHiForIntglActnInLatCtrl_out = zeros(1, 1, 'single');
VHysForIntglActnInLatCtrl_out = zeros(1, 1, 'single');
RampTiForIntglActnInLatCtrl_out = zeros(1, 1, 'single');
%PinionActvtyFiltGInLatCtrl_out = zeros(4, 1, 'single');
VForLrgPahOffsLimInLatCtrl_out = zeros(1, 8, 'single');
ALatLimAddlInLatCtrl_out = zeros(1, 8, 'single');
VLatLimInInLatCtrl_out = zeros(1, 8, 'single');
VLatLimOutInLatCtrl_out = zeros(1, 8, 'single');
LocalOffsForLimOutInLatCtrl_out = zeros(1, 8, 'single');
DrvrInLoopThdInLatCtrl_out = zeros(1, 1, 'single');
NoIntvPinionAngleReqInLatCtrl_out = zeros(1, 1, 'single');
%ManTstLocalOffsInLatCtrl_out = zeros(1, 1, 'single');
UseSlipCmpInLatCtrl_out = false(1, 1);
DisNonLinLimInLatCtrl_out = false(1, 1);
PinionActvtyTrgtValInLatCtrl_out = zeros(1, 8, 'single');
VForPinionAgCtrlKpInLatCtrl_out = zeros(1, 7, 'single');
PinionAgCtrlKpInLatCtrl_out = zeros(1, 7, 'single');
%ManTstModInLatCtrl_out = zeros(1, 1, 'int8');
%ManTstPinionAgReqInLatCtrl_out = zeros(1, 1, 'single');
UseLaneFilInLatCtrl_out = false(1, 1);
TunFacCtrlrLocalOffsGainInLatCtrl_out = zeros(1, 1, 'single');
% VLatCtrlrIntglGainInLatCtrl_out = zeros(1, 8, 'single');
PinionRMSForHigrActvtyInLatCtrl_out = zeros(1, 1, 'single');
PinionActvtyCtrlrLimInLatCtrl_out = zeros(1, 1, 'single');
LowrSpdLimForVLatLim_out = zeros(1, 1, 'single');
TiStepInLatCtrl_out = zeros(1, 1, 'single');
LowrPinionAgRateLimInLatCtrl_out = zeros(1, 4, 'single');
HighrPinionAgRateLimInLatCtrl_out = zeros(1, 8, 'single');
%HighrPinionAgRateLimInLatCtrl_out = zeros(8, 4, 'single');
PinionAgRateLimRateInLatCtrl_out = zeros(1, 4, 'single');
PinionAngleLowPassTauInLatCtrl_out = zeros(1, 1, 'single');
LowrDILPinionAgRateLimInLatCtrl_out = zeros(1, 4, 'single');
ManTunFacInLatCtrl_out = zeros(1, 4, 'single');
DelayForIntglActnInLatCtrl_out = zeros(1, 1, 'single');
% VLatCtrlrDrvGainInLatCtrl_out = zeros(1, 8, 'single');
LowPassTauRedFacInLatCtrl_out = zeros(1, 8, 'single');
HdWayLongInLatCtrl_out = zeros(1, 1, 'single');
HdWayLongerInLatCtrl_out = zeros(1, 1, 'single');
MaxTunFacDILDelayInLatCtrl_out = zeros(1, 1, 'single');
MinTunFacInLatCtrl_out = zeros(1, 8, 'single');
MaxTunFacInLatCtrl_out = zeros(1, 8, 'single');
TunFacEffRangeInLatCtrl_out = zeros(1, 1, 'single');
MaxTunFacDILRateInLatCtrl_out = zeros(1, 1, 'single');
TunFacCtrlrActvtyGainInLatCtrl_out = zeros(1, 1, 'single');
TunFacCtrlrLocalOffsThdInLatCtrl_out = zeros(1, 1, 'single');
% LowPassTauFFInLatCtrl_out = zeros(1, 8, 'single');
LowPassTauFFRedFacInLatCtrl_out = zeros(1, 8, 'single');
MaxTunFacDILInLatCtrl_out = zeros(1, 1, 'single');
RampVWdthForIntglActnInLatCtrl_out = zeros(1, 1, 'single');
LowrSpdLimforPathExtrapInLatCtrl_out = zeros(1, 1, 'single');
VForFFGainTunInLatCtrl_out=zeros(1, 7, 'single');
% FFGainTunInLatCtrl_out=zeros(1, 7, 'single');

if LCA_Executing
    HdWayNomInLatCtrl_out = LCA_HdWayNomInLatCtrl;
    LocalOffsCtrlrPropGainInLatCtrl_out = LCA_LocalOffsCtrlrPropGainInLatCtrl;
    VLatCtrlrPropGainInLatCtrl_out = LCA_VLatCtrlrPropGainInLatCtrl;
    VLatCtrlrIntglGainInLatCtrl_out = LCA_VLatCtrlrIntglGainInLatCtrl;
    VLatCtrlrDrvGainInLatCtrl_out = LCA_VLatCtrlrDrvGainInLatCtrl;
    FFGainTunInLatCtrl_out = LCA_FFGainTunInLatCtrl;
    LowPassTauInLatCtrl_out = LCA_LowPassTauInLatCtrl;
    LowPassTauFFInLatCtrl_out = LCA_LowPassTauFFInLatCtrl;
else
    HdWayNomInLatCtrl_out = HdWayNomInLatCtrl;
    % LocalOffsCtrlrPropGainInLatCtrl_out = LocalOffsCtrlrPropGainInLatCtrl;
    LocalOffsCtrlrPropGainInLatCtrl_out = LocalOffsCtrlrPropGainInLatCtrl;
    % VLatCtrlrPropGainInLatCtrl_out = VLatCtrlrPropGainInLatCtrl;
    VLatCtrlrPropGainInLatCtrl_out = VLatCtrlrPropGainInLatCtrl;
    % VLatCtrlrIntglGainInLatCtrl_out = VLatCtrlrIntglGainInLatCtrl;
    VLatCtrlrIntglGainInLatCtrl_out = VLatCtrlrIntglGainInLatCtrl;
    % VLatCtrlrDrvGainInLatCtrl_out = VLatCtrlrDrvGainInLatCtrl;
    VLatCtrlrDrvGainInLatCtrl_out = VLatCtrlrDrvGainInLatCtrl;   
    FFGainTunInLatCtrl_out = FFGainTunInLatCtrl;
    LowPassTauInLatCtrl_out = LowPassTauInLatCtrl;
    LowPassTauFFInLatCtrl_out = LowPassTauFFInLatCtrl;
end
        
HdWayMinInLatCtrl_out(:,:) = HdWayMinInLatCtrl(VehType,:);
LowrSpdLimInLatCtrl_out(:,:) = LowrSpdLimInLatCtrl(VehType,:);
LowrSpdLimSmthFacInLatCtrl_out(:,:) = LowrSpdLimSmthFacInLatCtrl(VehType,:);
EvnLowrSpdLimInLatCtrl_out(:,:) = EvnLowrSpdLimInLatCtrl(VehType,:);
VForLinTunInLatCtrl_out(:,:) = VForLinTunInLatCtrl(:,:);
% VForLinTunInLatCtrl_out = VForLinTunInLatCtrl;
PinionActvtyFiltSOSInLatCtrl_out(:,:) = PinionActvtyFiltSOSInLatCtrl; %%% NOTICE, same for all vehicle types
VHiForIntglActnInLatCtrl_out(:,:) = VHiForIntglActnInLatCtrl(VehType,:);
VHysForIntglActnInLatCtrl_out(:,:) = VHysForIntglActnInLatCtrl(VehType,:);
RampTiForIntglActnInLatCtrl_out(:,:) = RampTiForIntglActnInLatCtrl(VehType,:);
PinionActvtyFiltGInLatCtrl_out = PinionActvtyFiltGInLatCtrl; %%% NOTICE, same for all vehicle types
VForLrgPahOffsLimInLatCtrl_out(:,:) = VForLrgPahOffsLimInLatCtrl(VehType,:);
ALatLimAddlInLatCtrl_out(:,:) = ALatLimAddlInLatCtrl(VehType,:);
VLatLimInInLatCtrl_out(:,:) = VLatLimInInLatCtrl(VehType,:);
VLatLimOutInLatCtrl_out(:,:) = VLatLimOutInLatCtrl(VehType,:);
LocalOffsForLimOutInLatCtrl_out(:,:) = LocalOffsForLimOutInLatCtrl(VehType,:);
DrvrInLoopThdInLatCtrl_out(:,:) = DrvrInLoopThdInLatCtrl(VehType,:);
NoIntvPinionAngleReqInLatCtrl_out(:,:) = NoIntvPinionAngleReqInLatCtrl(VehType,:);
ManTstLocalOffsInLatCtrl_out = ManTstLocalOffsInLatCtrl;%%% NOTICE, same for all vehicle types
UseSlipCmpInLatCtrl_out(:,:) = UseSlipCmpInLatCtrl(VehType,:);
DisNonLinLimInLatCtrl_out(:,:) = DisNonLinLimInLatCtrl(VehType,:);
PinionActvtyTrgtValInLatCtrl_out(:,:) = PinionActvtyTrgtValInLatCtrl(VehType,:);
VForPinionAgCtrlKpInLatCtrl_out(:,:) = VForPinionAgCtrlKpInLatCtrl(VehType,:);
PinionAgCtrlKpInLatCtrl_out(:,:) = PinionAgCtrlKpInLatCtrl(VehType,:);
ManTstModInLatCtrl_out = ManTstModInLatCtrl;%%% NOTICE, same for all vehicle types
ManTstPinionAgReqInLatCtrl_out = ManTstPinionAgReqInLatCtrl;%%% NOTICE, same for all vehicle types
UseLaneFilInLatCtrl_out(:,:) = UseLaneFilInLatCtrl(VehType,:);
TunFacCtrlrLocalOffsGainInLatCtrl_out(:,:) = TunFacCtrlrLocalOffsGainInLatCtrl(VehType,:);
PinionRMSForHigrActvtyInLatCtrl_out(:,:) = PinionRMSForHigrActvtyInLatCtrl(VehType,:);
PinionActvtyCtrlrLimInLatCtrl_out(:,:) = PinionActvtyCtrlrLimInLatCtrl(VehType,:);
LowrSpdLimForVLatLim_out(:,:) = LowrSpdLimForVLatLim(VehType,:);
TiStepInLatCtrl_out(:,:) = TiStepInLatCtrl; %%%NOTICE, same for all vehicle types
LowrPinionAgRateLimInLatCtrl_out(:,:) = LowrPinionAgRateLimInLatCtrl(VehType,:);
HighrPinionAgRateLimInLatCtrl_out(:) = HighrPinionAgRateLimInLatCtrl(:,LateralControlModeRequestLimited); %%%NOTICE, same for all vehicle types
PinionAgRateLimRateInLatCtrl_out(:,:) = PinionAgRateLimRateInLatCtrl(VehType,:);
PinionAngleLowPassTauInLatCtrl_out(:,:) = PinionAngleLowPassTauInLatCtrl(VehType,:);
LowrDILPinionAgRateLimInLatCtrl_out(:,:) = LowrDILPinionAgRateLimInLatCtrl(VehType,:);
ManTunFacInLatCtrl_out(:,:) = ManTunFacInLatCtrl;%%% NOTICE, same for all vehicle types
DelayForIntglActnInLatCtrl_out(:,:) = DelayForIntglActnInLatCtrl(VehType,:);
LowPassTauRedFacInLatCtrl_out(:,:) = LowPassTauRedFacInLatCtrl(VehType,:);
HdWayLongInLatCtrl_out(:,:) = HdWayLongInLatCtrl(VehType,:);
HdWayLongerInLatCtrl_out(:,:) = HdWayLongerInLatCtrl(VehType,:);
MaxTunFacDILDelayInLatCtrl_out(:,:) = MaxTunFacDILDelayInLatCtrl(VehType,:);
MinTunFacInLatCtrl_out(:,:) = MinTunFacInLatCtrl(VehType,:);
MaxTunFacInLatCtrl_out(:,:) = MaxTunFacInLatCtrl(VehType,:);
TunFacEffRangeInLatCtrl_out(:,:) = TunFacEffRangeInLatCtrl(VehType,:);
MaxTunFacDILRateInLatCtrl_out(:,:) = MaxTunFacDILRateInLatCtrl(VehType,:);
TunFacCtrlrActvtyGainInLatCtrl_out(:,:) = TunFacCtrlrActvtyGainInLatCtrl(VehType,:);
TunFacCtrlrLocalOffsThdInLatCtrl_out(:,:) = TunFacCtrlrLocalOffsThdInLatCtrl(VehType,:);
LowPassTauFFRedFacInLatCtrl_out(:,:) = LowPassTauFFRedFacInLatCtrl(VehType,:);
MaxTunFacDILInLatCtrl_out(:,:) = MaxTunFacDILInLatCtrl(VehType,:);
RampVWdthForIntglActnInLatCtrl_out(:,:) = RampVWdthForIntglActnInLatCtrl(VehType,:);
LowrSpdLimforPathExtrapInLatCtrl_out(:,:) = LowrSpdLimforPathExtrapInLatCtrl(VehType,:);
VForFFGainTunInLatCtrl_out(:,:) = VForFFGainTunInLatCtrl(:,:);

VehicleSpeed_sat=min(VForBicycleMdlInLatCtrl(end), VehicleSpeed); %Note: saturation neccessary because clip doesnt work in n-D Lookup table (dSpace)
VehicleSpeed_sat=max(VForBicycleMdlInLatCtrl(1), VehicleSpeed_sat); 

if all(VForBicycleMdlInLatCtrl(:)==0)%% When running integration test all elements are set to zero
    bicycle_C_f_out=BicycleMdlCornrgStfnFrntInLatCtrl(1);
    bicycle_C_r_out=BicycleMdlCornrgStfnReInLatCtrl(1);
else
    bicycle_C_f_out=interp1(VForBicycleMdlInLatCtrl,BicycleMdlCornrgStfnFrntInLatCtrl,VehicleSpeed_sat,'linear','extrap');
    bicycle_C_r_out=interp1(VForBicycleMdlInLatCtrl,BicycleMdlCornrgStfnReInLatCtrl,VehicleSpeed_sat,'linear','extrap');
end

end