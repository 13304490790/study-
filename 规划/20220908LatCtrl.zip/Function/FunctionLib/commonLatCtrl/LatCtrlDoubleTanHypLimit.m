function y = LatCtrlDoubleTanHypLimit(x,LimitInner,LimitOuter,xForLimitOuter,eps)
% Limits input using two spliced hyberbolic tangent (smoothing) functions
% 
% Arguments:
%   x - input
%   LimitInner - Width (1/e) of the inner limiting funciton
%   LimitOuter - Width (1/e) of the outer limiting funciton
%   xForLimitOuter - x value at which the LocalOffsetLimitOuter applies
%
% Outputs:
%   y - The resulting limited value

%#codegen
A = LimitInner;
B = max(xForLimitOuter,LimitOuter + eps);
C = max(LimitOuter,LimitInner + eps);

k = (C-A)/B;
x0 = min( -(A*log(-((1 - k)^(1/2) - 1)/((1 - k)^(1/2) + 1)))/2  , B );
y0 = A*tanh(x0/A);

y1 = A*tanh(abs(x)/A).*(1 - LatCtrlTheta(abs(x) - x0));
y2 = ((C-A)*tanh((abs(x)-x0)/B) + y0).*LatCtrlTheta(abs(x) - x0);

y = (y1 + y2).*sign(x);
end