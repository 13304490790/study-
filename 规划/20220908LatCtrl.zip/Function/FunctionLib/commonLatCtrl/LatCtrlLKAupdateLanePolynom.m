function linePolynome = LatCtrlLKAupdateLanePolynom(linePolynome,A,B,C,D,len,tuneQual,dX,dTheta)

    if dTheta==0
        % If traveling in a streigth line
        X = dX;
    else
        % The radious of the line - radious of car minus the offset
        R = dX / dTheta - D;
        % The polynomial X transformation after rotation
        X = R * tan(dTheta);
        % The polynomial differance y(X)-y(0)
        Y = A * X*X*X + B * X*X + C * X;
        % save the value of the pulynomial
        Q = Y;

        % Loop a maximum of five times
        for n=1:5
            % Calculate the new position X
            X_p = Q * tan(dTheta) + X;
            % Calcylate the polynomial at this point
            Y_p = A * X_p*X_p*X_p + B * X_p*X_p + C * X_p;
            % Calculate the remaining differance
            Q = Y_p - Y; 
            % Save the new itteration point
            X = X_p;
            Y = Y_p;

            % If the error is small enough; break
            if abs(Q) < single(1e-9)
                break;
            end
        end
    end
    
    % Start by rotating the polynomial
    linePolynome.coeffC = linePolynome.coeffC + tan(dTheta);
    
    % Create X^2 and X^3
    X2=X*X;
    X3=X*X2;
    
    % Now translate
    B_new = linePolynome.coeffB + single(3)*X  .* linePolynome.coeffA;
    C_new = linePolynome.coeffC + single(3)*X2 .* linePolynome.coeffA + single(2)*X  .* linePolynome.coeffB;
    D_new = linePolynome.coeffD +   X3 .* linePolynome.coeffA +   X2 .* linePolynome.coeffB + X .* linePolynome.coeffC;
    
    % Stor the new values
    linePolynome.coeffB = B_new;
    linePolynome.coeffC = C_new;
    linePolynome.coeffD = D_new;

    % Decrease the tune Qual for all lines and decrease the range
    % TuneQual decreases more with large dTheta. Here tuneQual vill be
    % invalid after one frame if the car has a rotation of more than 1rad/s
    % All candidates also lose 10% of their tuneQual for each frame
    linePolynome.tuneQual = linePolynome.tuneQual * max(0,single(1)-abs(dTheta)*single(40)) * single(0.9);
    linePolynome.length   = linePolynome.length - X*(linePolynome.length > single(0));

    % If the range of any line drops below 0m or has a low tuneQual;
    % drop it as a candidate
    if any(linePolynome.length < single(0))
        for pos=1:length(linePolynome.length)
            if linePolynome.length(pos) < single(0)
                linePolynome.coeffA(pos)   = single(0);
                linePolynome.coeffB(pos)   = single(0);
                linePolynome.coeffC(pos)   = single(0);
                linePolynome.coeffD(pos)   = single(0);
                linePolynome.length(pos)   = single(0);
                linePolynome.tuneQual(pos) = single(0);
            end
        end
    end
    
    % Find the line candidate with the minimum tuneQual
    [Y,I] = min(linePolynome.tuneQual);

    % If the new line candidate has a larger tune qual than the stord line
    % candidate with the smallest tuneQual, store the new candidate.
    if tuneQual > Y
        linePolynome.coeffA(I)   = A;
        linePolynome.coeffB(I)   = B;
        linePolynome.coeffC(I)   = C;
        linePolynome.coeffD(I)   = D;
        linePolynome.length(I)   = len;
        linePolynome.tuneQual(I) = tuneQual;
    end

    % Calculate the coefficeients for the filtered polynome
    % If no valit tune qual or no valid lines, return zeros
    sclFactor = sum(linePolynome.tuneQual);
    if sclFactor > single(0)
        % Calculate FltDstLgtToEnd as a weighted average of the distances,
        % increase vith 13% as a car driving streight with a speed of 30m/s
        linePolynome.FltDstLgtToEnd = linePolynome.length' * linePolynome.tuneQual / sclFactor * (single(0.985)+single(0.05)*dX+single(eps*40));
        
        % Calculate de filtered line information
        % a line with a short range will with this method only contribute
        % to the lower coefficients in the polynom
        linePolynome.FltDstLatThrdCoeff  = determinCoeff(linePolynome.FltDstLgtToEnd, linePolynome.tuneQual, linePolynome.length, linePolynome.coeffA, single(4));
        linePolynome.FltDstLatSecCoeff   = determinCoeff(linePolynome.FltDstLgtToEnd, linePolynome.tuneQual, linePolynome.length, linePolynome.coeffB, single(3));
        linePolynome.FltDstLatFirstCOeff = determinCoeff(linePolynome.FltDstLgtToEnd, linePolynome.tuneQual, linePolynome.length, linePolynome.coeffC, single(2));
        linePolynome.FltDstLatConCoeff   = determinCoeff(linePolynome.FltDstLgtToEnd, linePolynome.tuneQual, linePolynome.length, linePolynome.coeffD, single(1));

    else
        % If no valid lines exist, return zeros
        linePolynome.FltDstLgtToEnd      = single(0);
        linePolynome.FltDstLatThrdCoeff  = single(0);
        linePolynome.FltDstLatSecCoeff   = single(0);
        linePolynome.FltDstLatFirstCOeff = single(0);
        linePolynome.FltDstLatConCoeff   = single(0);
    end
end


function FltCoeff = determinCoeff(FltDstLgtToEnd, tuneQual, length, coeff, segment)
    % Segment is 1,2,3 or 4 of FltDstLgtToEnd
    %                 In segemnts:        1       2       3       4
    %                 In geometry:    |-------|-------|-------|-------|
    %                 In percentage: 0%      25%     50%     75%     100%
    
    % Calculate low and high level for segment
    lowLvlSeg = FltDstLgtToEnd / single(4) * (segment-1);
    higLvlSeg = FltDstLgtToEnd / single(4) * segment;
    
    % Create a scaled tuneQual baced on segemnt information
    scaledTuneQual = (length > lowLvlSeg).*(min((length-lowLvlSeg)./(higLvlSeg-lowLvlSeg),1)).*tuneQual;
    
    % Use the scaled tuneQual for filtering of the coeff
    FltCoeff   = coeff' * scaledTuneQual / sum(scaledTuneQual);
end
