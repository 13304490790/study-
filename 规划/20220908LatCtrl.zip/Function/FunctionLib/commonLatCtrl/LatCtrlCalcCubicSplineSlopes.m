function b = LatCtrlCalcCubicSplineSlopes(splineX, splineY, n)
    % TjaCalcCubicSplineSlopes - Calculates the slopes for a cubic spline
    %   interpolant which are needed to complete the Hermite form of the
    %   spline.
    %
    % Arguments:
    %   splineX - The vector of x-coordinates for the points to interpolate.
    %   splineY - The vector of y-coordinates for the points to interpolate.
    %   n - The number of coordinates in the input.
    %
    % Output:
    %   k - The slope of the interpolant calculated at each coordinate.

    %#codegen

    trailSize = cast(50, class(n));
    sys = zeros(trailSize, 2, class(splineX));
    b = zeros(trailSize, 1, class(splineX));
    dx = diff(splineX);
    dy = diff(splineY);

    if n < 2
        if n == 1
            b(1) = 0;
        end
        return;
    elseif n > trailSize
        n = trailSize; % Disregard any extraneous points
    end

    % generate the two diagonals of the system
    sys(1, 1) = 2 / dx(1);
    sys(1, 2) = 1 / dx(1);
    b(1) = 3 * dy(1) / dx(1)^2;
    for i = 2:(n-1)
        sys(i, 1) = 2 * ( 1 / dx(i - 1) + 1 / dx(i));
        sys(i, 2) = 1 / dx(i);
        b(i) = 3 * (dy(i - 1) / dx(i - 1)^2 + dy(i) / dx(i)^2);
    end
    sys(n, 1) = 2 / dx(n - 1);
    sys(n, 2) = 0;
    b(n) = 3 * dy(n - 1) / dx(n - 1)^2;

    % Simple symmetric tridiagonal system => solve with gaussian elimination
    for i = 2:n
        ratio = sys(i - 1, 2) / sys(i - 1, 1);
        sys(i, 1) = sys(i, 1) - ratio * sys(i - 1, 2);
        b(i) = b(i) - ratio * b(i - 1);
    end

    % Back substitution
    % Calculate k and store it in b to avoid additional matrix usage
    b(n) = b(n) / sys(n, 1);
    for i = (n - 1):-1:1
        b(i) = (b(i) - b(i + 1) * sys(i, 2)) / sys(i, 1);
    end

end

