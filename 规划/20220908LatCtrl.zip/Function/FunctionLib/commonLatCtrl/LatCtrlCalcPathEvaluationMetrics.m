function [LookaheadEffectiveDistance, LookaheadEffectiveTime] = LatCtrlCalcPathEvaluationMetrics(ValidRange,VehicleSpeed,VehicleSpeedLimited,LookAheadNominalTime,LookAheadMinimumTime,LowrSpdLimforPathExtrap)
% Calculates LookAheadEffectiveDistance and LookAheadEffectiveTime
% 
% Arguments:
%   ValidRange
%   VehicleSpeed
%   VehicleSpeedLimited
%   LookAheadNominalTime
%   LookAheadMinimumTime
%   LRear
% 
% Outputs:
%   LookaheadEffectiveDistance
%   LookaheadEffectiveTime

%#codegen

% New version 2015-10-23 Lars Johannesson M�rdh
% Allow extrapolation beyond ValidRange
% The activation speed for the new code is decided by
% LowrSpdLimforPathExtrap which is set to 30/3.6;

%A comment to please Model Advisor
%A comment to please Model Advisor
%A comment to please Model Advisor
%A comment to please Model Advisor
%A comment to please Model Advisor

if VehicleSpeed>LowrSpdLimforPathExtrap %A comment to please Model Advisor
    
    if  ValidRange < (LookAheadMinimumTime*VehicleSpeed) %A comment to please Model Advisor
        LookaheadEffectiveDistance = LookAheadMinimumTime*VehicleSpeedLimited;
        LookaheadEffectiveTime = LookAheadMinimumTime;
        
    elseif (ValidRange < (LookAheadNominalTime*VehicleSpeedLimited)) && (ValidRange > (LookAheadNominalTime*VehicleSpeed))
        LookaheadEffectiveDistance = max(ValidRange, LookAheadMinimumTime*VehicleSpeedLimited);
        LookaheadEffectiveTime = LookAheadNominalTime;
        
    elseif ValidRange <= (LookAheadNominalTime*VehicleSpeed) %A comment to please Model Advisor
        LookaheadEffectiveDistance = max(ValidRange, LookAheadMinimumTime*VehicleSpeedLimited);
        LookaheadEffectiveTime = min(ValidRange/VehicleSpeed,LookAheadNominalTime); %VehicleSpeed is guaranteed to not be zero
        
    else %A comment to please Model Advisor
        LookaheadEffectiveDistance = LookAheadNominalTime*VehicleSpeedLimited;
        LookaheadEffectiveTime = LookAheadNominalTime;
        
    end
else % allow extrapolation beyond ValidRange
    LookaheadEffectiveDistance = LookAheadNominalTime*VehicleSpeedLimited;
    LookaheadEffectiveTime =   LookAheadNominalTime;
end

end

