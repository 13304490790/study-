function Gain = LatCtrlLimitStandStillGain(Vx, VxWidth, ReducedGain, VxOffset)
% Limits Gain for very low speeds using exponential function
% Arguments:
% 
% Vx - VehicleSpeed
% VxWidth - 1/e width of limiting function, i.e. where the gain function reaches 63% of (1 - ReducedGain)
% ReducedGain - The ramaning gain at zero speed
% VxOffset - Speed which below Gain is constantly (clipped to) ReducedGain

Gain = single(1) + (ReducedGain - single(1)).*exp(-(Vx-VxOffset)./VxWidth);
Gain = max(Gain,ReducedGain);

end