function [yValues kValues] = TjaEvaluateCubicSpline(splineX, splineY, slopes, n, xValues)
    % TjaEvaluateCubicSpline - Evaluates a cubic spline interpolant described
    %   on its Hermite form in a number of points.
    %
    % Arguments:
    %   splineX - The vector of x-coordinates for the points to interpolate.
    %   splineY - The vector of y-coordinates for the points to interpolate.
    %   slopes - The slopes of the interpolant at each point.
    %   n - The number of points in the input.
    %   xValues - The values on the x-axis to evaluate the interpolant on.
    %
    % Output:
    %   yValues - The values on the y-axis for the evaluated interpolant.
    %   kValues - The derivative of the evaluated interpolant

    %#codegen

    yValues = zeros(size(xValues), 'single');
    kValues = zeros(size(xValues), 'single');
    if n < 1
        return;
    end
    
    for i = 1:length(xValues)
        x = xValues(i);
        if x <= splineX(1)
            % Extrapolate the first segment with zero second derivative
            yValues(i) = splineY(1) + (x - splineX(1)) * slopes(1);
            kValues(i) = slopes(1);
        elseif x >= splineX(n)
            % Extrapolate the last segment with zero second derivative
            yValues(i) = splineY(n) + (x - splineX(n)) * slopes(n);
            kValues(i) = slopes(n);
        else
            segment = 1;
            while segment < (n - 1) && splineX(segment + 1) <= x
                segment = segment + 1;
            end

            x1 = splineX(segment);
            x2 = splineX(segment + 1);
            k1 = slopes(segment);
            k2 = slopes(segment + 1);
            y1 = splineY(segment);
            y2 = splineY(segment + 1);

            t = (x - x1) / (x2 - x1);

            a = k1 * (x2 - x1) - (y2 - y1);
            b = -k2 * (x2 - x1) + (y2 - y1);

            yValues(i) = (1 - t) * y1 + t * y2 + ...
                t * (1 - t) * (a * (1 - t) + b * t);
            
            kValues(i) = ( 3*(a-b)*t^2 + 2*(b-2*a)*t + (a-y1+y2) )/(x2-x1);
        end
    end
end

