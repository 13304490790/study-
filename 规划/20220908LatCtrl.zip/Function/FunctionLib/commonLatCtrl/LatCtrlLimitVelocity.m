function Vlim = LatCtrlLimitVelocity( Vx, Vmin, delta )
%Description: Transition between line y1=a*Vx+b=Vmin and y2=c*Vx+d=Vx is
%performed on interval 2*delta.Code is based on paper: "On smoothing of
%non-smooth functions" by Alexander Alenitsyn"

%-----------------Inputs----------------------------------------
%Vx             Velocity of ego vehicle [m/s]
%Vmin           Minumum velocity allowed in the lateral controller [m/s]
%delta          Smooting radius, >0

%---------------Outputs----------------------------------------
%Vlim           Limited verision of Vx [m/s]

%#codegen
if Vx < (Vmin - delta)
    Vlim = Vmin;
elseif (Vx >= (Vmin - delta)) && (Vx <= (Vmin + delta))
    a = single(0);  %y1=a*Vx+b=Vmin;
    b = Vmin;
    c = single(1);  %y2=c*Vx-d=Vx;
    d = single(0);
    x0 = Vmin; %midpoint of the transition interval [x0-delta, x0+delta]. Outside this interval the lines y1 and y2 remain straight.  
    A = (c-a)/single(2);
    B = (d-b) + delta*(a+c);
    C = x0^2*(a-c)/single(2) + x0*(b-d)+delta*(b+d) + delta^2*(c-a)/single(2);
    Vlim = (A*Vx^2 + B*Vx+C)/(single(2)*delta); %smooth transition between y1 and y2
    
else % when Vx>Vmin+delta
    Vlim = Vx;
end
end

