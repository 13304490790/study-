function [CurvatureDesired,LocalOffsetIntegratorMax,LocalOffsetIntegratorMin,DisableLocalOffsetIntegrator, LookAheadOffsetLimited,LocalOffsetLimited]= LatCtrlCalcCurvatureDesired(UseVLatLimit,UseALatLimit,LookAheadOffsetFiltered,LookAheadOffset,LocalOffset,LookAheadEffectiveTime,LookAheadEffectiveDistance,LocalHeading,ALatAdditional,VehicleSpeedLimitedHigh,VehicleSpeedLimitedLow,LocalOffsetForOuterLimit,OuterGain,ALatLimitSmootingFactor,VLatLimitOuter,VLatLimitInner,eps)
% Calulates the desired curvature based on the metric LookAheadOffset (a.k.a. yL2).
% Limits the requested YawRate in large path local offset or large path heading offset�
% situations, in order to make the system robust to non-linear limitations (mainly level and 
% rate limitation of pinionangle).
%
% Arguments:
%   UseVLatLimit - Boolean used to enable/disable limitation of lateral speed relative to path
%   UseALatLimit - Boolean used to enable/disable limitation of lateral acceleration relative to path
%   LookAheadOffsetFiltered - LookAheadOffset ("yL2") scaled and filtered (loop shaping)
%   LookAheadOffset - Physical metric of path offset at lookahead distance ("yL2")
%   LocalOffset - Physical metric of local path offset "Deltay"
%   LookAheadEffectiveTime - Time ahead of vehicle at which LookAheadOffset is measured
%   LookAheadEffectiveDistance - Distance ahead of vehicle at which LookAheadOffset is measured
%   LocalHeading - Heading of path relative to vehicle x axis (path derivative at x=0)
%   ALatAdditional - Additional lateral acceleration allowed relative to path
%   VLatAdditional - Additional lateral velocity allowed relative to path
%   VehicleSpeed - Vehicle Speed
%   LocalOffsetForOuterLimit - The local offset at which VLatLimitOuter is used as limit
%   OuterGain - Outer loop gain factor acting on LookAheadOffsetFiltered
%   VLatLimitOuter - The lateral velocity limitation at LocalOffsetForOuterLimit
%   VLatLimitInner - The innner (minimum) lateral velocity limitation
%
% Outputs:
%   CurvatureDesired - the resulting yL2 derived curvature to be achieved
%   LocalOffsetIntegratorMax - the remainder after limitation of yL2 may be used by the local offset integrator
%   LocalOffsetIntegratorMin - the remainder after limitation of yL2 may be used by the local offset integrator
%   LookAheadOffsetLimited - the limited version of yL2
%   LocalOffsetLimited - the limited version of deltay
%   VLat - local heading derived lateral speed

%#codegen
DeltayL2 = LookAheadOffset - LocalOffset - LocalHeading*LookAheadEffectiveDistance;
yL2_ALatLimit = ALatAdditional*LookAheadEffectiveDistance^2/(2*VehicleSpeedLimitedLow^2) + eps;
LookAhead2CurvatureGain = 2/LookAheadEffectiveDistance^2;

LocalOffsetLimitInner = max(VLatLimitInner*LookAheadEffectiveDistance/VehicleSpeedLimitedLow,eps);
LocalOffsetLimitOuter = max(VLatLimitOuter*LookAheadEffectiveDistance/VehicleSpeedLimitedLow,eps);

if UseVLatLimit
    LocalOffsetLimited = LatCtrlDoubleTanHypLimit(LocalOffset,LocalOffsetLimitInner,LocalOffsetLimitOuter,LocalOffsetForOuterLimit,eps);
    LookAheadOffsetVLatLimited = LookAheadOffsetFiltered - LocalOffset*OuterGain + LocalOffsetLimited*OuterGain;
    if UseALatLimit
        LookAheadOffsetLimited = LatCtrlDoubleTanHypLimit(LookAheadOffsetVLatLimited - DeltayL2*OuterGain,yL2_ALatLimit/ALatLimitSmootingFactor,yL2_ALatLimit,yL2_ALatLimit*ALatLimitSmootingFactor,eps) + DeltayL2*OuterGain;
    else
        LookAheadOffsetLimited = LookAheadOffsetVLatLimited;
    end
else
    if UseALatLimit
        LookAheadOffsetLimited = LatCtrlDoubleTanHypLimit(LookAheadOffsetFiltered - DeltayL2*OuterGain,yL2_ALatLimit/ALatLimitSmootingFactor,yL2_ALatLimit,yL2_ALatLimit*ALatLimitSmootingFactor,eps) + DeltayL2*OuterGain;
    else
        LookAheadOffsetLimited = LookAheadOffsetFiltered;
    end
    LocalOffsetLimited = LocalOffset;
end

CurvatureDesired = LookAheadOffsetLimited*LookAhead2CurvatureGain;

LocalOffsetIntegratorMax = min( max(+LocalOffsetLimitInner-LocalOffset,0) , +LocalOffsetLimitInner )*LookAhead2CurvatureGain;
LocalOffsetIntegratorMin = max( min(-LocalOffsetLimitInner-LocalOffset,0) , -LocalOffsetLimitInner )*LookAhead2CurvatureGain;

DisableLocalOffsetIntegrator = abs(LocalOffset) > LocalOffsetLimitInner;

end
