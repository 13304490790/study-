function y = LatCtrlTanHypLinLimit(x,LimitInner,LimitOuter,xForLimitOuter,eps)
% Limits input using two spliced functions - one hyberbolic tangent and
% one linear.
% 
% Arguments:
%   x - input     Localoffset * PGain, 

%   LimitInner - Width (1/e) of the inner limiting funciton
%   VLatLimitInner*VLatLimFactor  [1 1 2 3 4 4 4 4] * [0.9,0.8 ]
%   LimitOuter - Width (1/e) of the outer limiting funciton
%   VLatLimitOuter*VLatLimFactor  [1 2 4 6 6 6 6 6] *  [0.9]
%   xForLimitOuter - x value at which the LocalOffsetLimitOuter applies
%   PGain*LocalOffsetForOuterLimit  [1.5 1.5 1.5 1.5 1.5 1.5]* [0.25 0.25 0.6 0.7 0.7 0.7]
%   
% Outputs:
%   y - The resulting limited value

%#codegen
A = LimitInner;
B = max(xForLimitOuter,LimitOuter + eps);
C = max(LimitOuter,LimitInner + eps);

k = (C-A)/B;
x0 = min( -(A*log(-((1 - k)^(1/2) - 1)/((1 - k)^(1/2) + 1)))/2  , B );
y0 = A*tanh(x0/A);

y1 = A*tanh(abs(x)/A).*(1 - LatCtrlTheta(abs(x) - x0));
y2 = ((abs(x)-x0)*k + y0).*LatCtrlTheta(abs(x) - x0);

y = (y1 + y2).*sign(x);
end