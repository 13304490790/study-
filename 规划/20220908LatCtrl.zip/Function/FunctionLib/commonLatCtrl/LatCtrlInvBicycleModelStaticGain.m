function Gain = LatCtrlInvBicycleModelStaticGain(m, C_f, C_r, l_f, l_r, SteerRatio, Vx)
% Calculates Curvature to PinionAngle static Gain via inverse bicycle model
% note: replaced a^2 by a*a because of ModelAdvisor warnings
%#codegen
Gain = SteerRatio*(-C_f*m*Vx*Vx*l_f + C_r*m*Vx*Vx*l_r+C_f*C_r*l_f*l_f+2*C_f*C_r*l_f*l_r + C_f*C_r*l_r*l_r)/(C_f*C_r*(l_f + l_r)+eps);
end