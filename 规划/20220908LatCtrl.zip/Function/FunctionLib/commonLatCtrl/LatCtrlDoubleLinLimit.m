function y = LatCtrlDoubleLinLimit(x,LimitInner,LimitOuter,xForLimitOuter,eps)
% Limits input using two spliced linear functions
% 
% Arguments:
%   x - input 
%   LimitInner - inner limiting funciton
%   LimitOuter - outer limiting funciton
%   xForLimitOuter - x value at which the LimitOuter applies
%
% Outputs:
%   y - The resulting limited value

%#codegen

y = interp1([-xForLimitOuter -LimitInner LimitInner xForLimitOuter],[-LimitOuter -LimitInner LimitInner LimitOuter],x,'linear','extrap');

end