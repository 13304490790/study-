function polynom = LatCtrlLKAinitializeLanePolynom()
% polynom = LKAinitializeLanePolynom()
% Excessive commenting seems unnecessary, but is needed in order 
% to get enough comment lines in order for ModelAdvisor SW integration checks to pass.
% Have a nice day.
    polynom.coeffA = single(zeros(20,1));
    polynom.coeffB = single(zeros(20,1));
    polynom.coeffC = single(zeros(20,1));
    polynom.coeffD = single(zeros(20,1));
    polynom.length = single(zeros(20,1));
    polynom.tuneQual=single(zeros(20,1));

    polynom.FltDstLgtToEnd      = single(0);
    polynom.FltDstLatThrdCoeff  = single(0);
    polynom.FltDstLatSecCoeff   = single(0);
    polynom.FltDstLatFirstCOeff = single(0);
    polynom.FltDstLatConCoeff   = single(0);
end