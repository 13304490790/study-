classdef LatCtrlRunningAverage < handle
%#codegen
% A running avergage flter
% 
% Arguments
%   type - string containing the data type of the filter bank elements
%   N - size of filter bank
% 
% Outputs
%   y - filter output
%   n - filter taps currently used by filter

properties (Access = private)
   w;
   n;
   N;
end

methods (Access = public) 

    function self = LatCtrlRunningAverage(type, N)
        self.w = zeros(1, N, type);
        self.n = zeros(1, 1, 'int32');
    end
    
    function reset(self)
        self.w = zeros(size(self.w), class(self.w));
        self.n = zeros(size(self.n), class(self.n));
    end
    
    function [y n] = update(self, x)
        self.n = min( self.n + ones(size(self.n), class(self.n)) , length(self.w) );
        self.w = [x self.w(1:length(self.w)-1)];
        n = self.n;
        y = sum(self.w)/cast(self.n, class(self.w));
    end
end

end