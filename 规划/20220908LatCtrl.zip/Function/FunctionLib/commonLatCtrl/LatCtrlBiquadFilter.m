classdef LatCtrlBiquadFilter < handle
% Second order IIR filter using nomalized Direct Form II realizing the transfer function
% H(z) = (b1 + b2*z^-1  + b3*z^-1)/(a1 + a2*z^-1 + a3*z^-1) where the
% filter coefficients is normalised by a1.
%#codegen    

properties (Access = private)
   w; 
   a; 
   b;
end
    
methods (Access = public) 

    function self = LatCtrlBiquadFilter(type, b, a)
        self.a = a; 
        self.b = b; 
        self.w = zeros(1, 3, type);  
    end
    
    function reset(self)
        self.w = zeros(size(self.w), class(self.w));  
    end
    
    function y = update(self, x)
        self.w(1) = x - self.a(2)*self.w(2) - self.a(3)*self.w(3);
        y = self.b(1)*self.w(1) + self.b(2)*self.w(2) + self.b(3)*self.w(3);
        self.w = [self.w(1) self.w(1:2)];
    end

end

end