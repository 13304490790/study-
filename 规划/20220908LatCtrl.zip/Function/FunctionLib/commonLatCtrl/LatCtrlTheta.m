function y = LatCtrlTheta(x)
%#codegen
y = single(x >= 0);
end
