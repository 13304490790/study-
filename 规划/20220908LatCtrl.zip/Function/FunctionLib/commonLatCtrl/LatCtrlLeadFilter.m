function y = LatCtrlLeadFilter(input, reset, Tau, b, Ts)
%#codegen
%Description: Discrete implementation of the continious lead filter 
%G_lead_continious = (1+s*Tau)/(1+s*Tau) using Tustin transformation 
%(also known as bilinear transformation), hence s=2*(z-1)/(Ts*(z+1));

%--------------Inputs----------------------------------------------
%input                  input to lead filter
%reset                  Boolean indicating whether to reset the system
%Tau                    lead filter parameter, see Description section
%b                      Lead filter parameter, see Description section
%Ts                     Sample time
%-------------------------------------------------------------------

%--------------Outputs----------------------------------------------
%y                     the output from the lead filter
%-------------------------------------------------------------------
persistent input_prev;
persistent output_prev;


if isempty(input_prev)
    input_prev = single(0);
end

if isempty(output_prev)
    output_prev = single(0);
end

if reset
    y = input;
else
    d1 = (b*Ts+2*Tau*b)/(b*Ts+2*Tau);
    d2 = (b*Ts-2*Tau*b)/(b*Ts+2*Tau);
    d3 = (b*Ts-2*Tau)/(b*Ts+2*Tau);
    y = input*d1+input_prev*d2-output_prev*d3; %compute output using tustin transformation
end

input_prev = input;
output_prev = y;